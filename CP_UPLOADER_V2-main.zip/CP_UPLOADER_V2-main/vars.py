import os
from dotenv import load_dotenv

load_dotenv()

API_ID = int(os.environ.get("API_ID", "12345678"))
API_HASH = os.environ.get("API_HASH", "your_api_hash_here")
BOT_TOKEN = os.environ.get("BOT_TOKEN", "your_bot_token_here")
OWNER = int(os.environ.get("OWNER", "8048202739"))
CREDIT = os.environ.get("CREDIT", "𝐈𝐓𝐬𝐆𝐎𝐋𝐔")
LOG_CHANNEL = int(os.environ.get("LOG_CHANNEL", "-1002731819287"))

# API URL - Change this to your Vercel URL
API_URL = os.environ.get("API_URL", "https://your-vercel-app.vercel.app")
