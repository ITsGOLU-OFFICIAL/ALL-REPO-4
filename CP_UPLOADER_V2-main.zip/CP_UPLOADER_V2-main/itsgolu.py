import os
import re
import time
import mmap
import datetime
import aiohttp
import aiofiles
import asyncio
import logging
import requests
import subprocess
import concurrent.futures
import uuid
import random
import imaplib
import email
from email.header import decode_header
from math import ceil
from utils import progress_bar
from pyrogram import Client, filters
from pyrogram.types import Message
from io import BytesIO
from pathlib import Path
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from base64 import b64decode

# Sanitize filename function
def sanitize_filename(filename):
    """
    Removes or replaces invalid characters from a filename.
    """
    # Replace invalid characters with underscore
    sanitized = re.sub(r'[<>:"/\\|?*\x00-\x1F]', '_', filename)
    # Also remove leading/trailing dots/spaces (Windows restriction)
    sanitized = sanitized.strip('. ')
    # Limit length (optional, filesystem dependent)
    # sanitized = sanitized[:250] if len(sanitized) > 250 else sanitized
    return sanitized if sanitized else "unnamed_file"

def duration(filename):
    result = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                             "format=duration", "-of",
                             "default=noprint_wrappers=1:nokey=1", filename],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT)
    return float(result.stdout)

def get_mps_and_keys(api_url, token=None):
    # Updated to use token from API
    headers = {}
    if token:
        headers['x-access-token'] = token
    
    try:
        response = requests.get(api_url, headers=headers)
        response_json = response.json()
        
        # Handle different response formats
        if response_json.get("success"):
            # New API format
            if "mpd" in response_json:
                mpd = response_json.get('mpd')
                keys = response_json.get('keys', [])
            elif "url" in response_json:
                mpd = response_json.get('url')
                keys = []
            else:
                mpd = None
                keys = []
        else:
            # Legacy format
            mpd = response_json.get('MPD')
            keys = response_json.get('KEYS', [])
            
        return mpd, keys
    except Exception as e:
        logging.error(f"Error in get_mps_and_keys: {str(e)}")
        return None, None
   
def exec(cmd):
        process = subprocess.run(cmd, stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        output = process.stdout.decode()
        print(output)
        return output

def pull_run(work, cmds):
    with concurrent.futures.ThreadPoolExecutor(max_workers=work) as executor:
        print("Waiting for tasks to complete")
        fut = executor.map(exec,cmds)

async def aio(url,name):
    k = f'{name}.pdf'
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            if resp.status == 200:
                f = await aiofiles.open(k, mode='wb')
                await f.write(await resp.read())
                await f.close()
    return k

async def download(url,name):
    ka = f'{name}.pdf'
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            if resp.status == 200:
                f = await aiofiles.open(ka, mode='wb')
                await f.write(await resp.read())
                await f.close()
    return ka

async def pdf_download(url, file_name, chunk_size=1024 * 10):
    if os.path.exists(file_name):
        os.remove(file_name)
    r = requests.get(url, allow_redirects=True, stream=True)
    with open(file_name, 'wb') as fd:
        for chunk in r.iter_content(chunk_size=chunk_size):
            if chunk:
                fd.write(chunk)
    return file_name   

def parse_vid_info(info):
    info = info.strip()
    info = info.split("\n")
    new_info = []
    temp = []
    for i in info:
        i = str(i)
        if "[" not in i and '---' not in i:
            while "  " in i:
                i = i.replace("  ", " ")
            i.strip()
            i = i.split("|")[0].split(" ",2)
            try:
                if "RESOLUTION" not in i[2] and i[2] not in temp and "audio" not in i[2]:
                    temp.append(i[2])
                    new_info.append((i[0], i[2]))
            except:
                pass
    return new_info

def vid_info(info):
    info = info.strip()
    info = info.split("\n")
    new_info = dict()
    temp = []
    for i in info:
        i = str(i)
        if "[" not in i and '---' not in i:
            while "  " in i:
                i = i.replace("  ", " ")
            i.strip()
            i = i.split("|")[0].split(" ",3)
            try:
                if "RESOLUTION" not in i[2] and i[2] not in temp and "audio" not in i[2]:
                    temp.append(i[2])
                    new_info.update({f'{i[2]}':f'{i[0]}'})
            except:
                pass
    return new_info

async def decrypt_and_merge_video(mpd_url, keys_string, output_path, output_name, quality="720", token=None):
    try:
        output_path = Path(output_path)
        output_path.mkdir(parents=True, exist_ok=True)

        # Try multiple download commands for DRM content
        download_commands = [
            # Command 1: Basic yt-dlp without format selector
            f'yt-dlp --allow-unplayable-format --no-check-certificate --external-downloader aria2c --downloader-args "aria2c: -x 16 -j 32" -o "{output_path}/file.%(ext)s" "{mpd_url}"',
            # Command 2: yt-dlp with best format selector
            f'yt-dlp -f "best" --allow-unplayable-format --no-check-certificate --external-downloader aria2c --downloader-args "aria2c: -x 16 -j 32" -o "{output_path}/file.%(ext)s" "{mpd_url}"',
            # Command 3: yt-dlp with specific quality
            f'yt-dlp -f "best[height<={quality}]" --allow-unplayable-format --no-check-certificate --external-downloader aria2c --downloader-args "aria2c: -x 16 -j 32" -o "{output_path}/file.%(ext)s" "{mpd_url}"',
            # Command 4: yt-dlp with all formats
            f'yt-dlp -f "bestvideo[height<={quality}]+bestaudio" --allow-unplayable-format --no-check-certificate --external-downloader aria2c --downloader-args "aria2c: -x 16 -j 32" -o "{output_path}/file.%(ext)s" "{mpd_url}"',
            # Command 5: yt-dlp with fallback
            f'yt-dlp -f "bestvideo+bestaudio/best" --allow-unplayable-format --no-check-certificate --external-downloader aria2c --downloader-args "aria2c: -x 16 -j 32" -o "{output_path}/file.%(ext)s" "{mpd_url}"'
        ]

        download_success = False
        download_output = ""

        for idx, cmd in enumerate(download_commands):
            print(f"Trying download command {idx+1}: {cmd}")
            process = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            download_output = process.stdout.decode() + process.stderr.decode()
            print(f"Command {idx+1} output: {download_output}")
            
            if process.returncode == 0:
                download_success = True
                break
            else:
                print(f"Command {idx+1} failed with return code {process.returncode}")
        
        if not download_success:
            raise Exception(f"All download methods failed. Last error: {download_output}")
        
        # List all files in the directory
        avDir = list(output_path.iterdir())
        print(f"Downloaded files: {[f.name for f in avDir]}")
        
        if not avDir:
            raise FileNotFoundError("No files found after download")
        
        # Find video and audio files
        video_file = None
        audio_file = None
        
        for file in avDir:
            if file.suffix in ['.mp4', '.webm', '.mkv']:
                video_file = file
            elif file.suffix in ['.m4a', '.webm', '.mp3']:
                audio_file = file
        
        if not video_file:
            raise FileNotFoundError("Video file not found")
        
        if not audio_file:
            print("Warning: Audio file not found, proceeding with video only")
            # If no audio file, just return the video file
            final_output = output_path / f"{output_name}.mp4"
            if video_file.suffix == '.mp4':
                os.rename(video_file, final_output)
            else:
                # Convert to mp4 if needed
                cmd = f'ffmpeg -i "{video_file}" -c copy "{final_output}"'
                subprocess.run(cmd, shell=True)
                video_file.unlink()
            return str(final_output)
        
        print(f"Found video: {video_file.name}, audio: {audio_file.name}")
        
        # Decrypt files if keys are provided
        if keys_string:
            print("Decrypting files...")
            
            # Decrypt video
            decrypted_video = output_path / "video.mp4"
            cmd2 = f'mp4decrypt {keys_string} --show-progress "{video_file}" "{decrypted_video}"'
            print(f"Running video decryption: {cmd2}")
            subprocess.run(cmd2, shell=True)
            
            if not decrypted_video.exists():
                raise FileNotFoundError("Video decryption failed")
            
            # Decrypt audio
            decrypted_audio = output_path / "audio.m4a"
            cmd3 = f'mp4decrypt {keys_string} --show-progress "{audio_file}" "{decrypted_audio}"'
            print(f"Running audio decryption: {cmd3}")
            subprocess.run(cmd3, shell=True)
            
            if not decrypted_audio.exists():
                raise FileNotFoundError("Audio decryption failed")
            
            # Clean up original files
            video_file.unlink()
            audio_file.unlink()
            
            video_file = decrypted_video
            audio_file = decrypted_audio
        
        # Merge video and audio
        final_output = output_path / f"{output_name}.mp4"
        cmd4 = f'ffmpeg -i "{video_file}" -i "{audio_file}" -c copy "{final_output}"'
        print(f"Running merge command: {cmd4}")
        subprocess.run(cmd4, shell=True)
        
        if not final_output.exists():
            raise FileNotFoundError("Merged video file not found")
        
        # Clean up temporary files
        video_file.unlink()
        audio_file.unlink()
        
        # Get duration for verification
        cmd5 = f'ffmpeg -i "{final_output}" 2>&1 | grep "Duration"'
        duration_info = subprocess.run(cmd5, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout.decode()
        print(f"Duration info: {duration_info}")
        
        return str(final_output)

    except Exception as e:
        print(f"Error during decryption and merging: {str(e)}")
        # Clean up any remaining files
        for file in output_path.glob("*"):
            if not file.name.startswith(output_name):
                try:
                    file.unlink()
                except:
                    pass
        raise

async def run(cmd):
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE)

    stdout, stderr = await proc.communicate()

    print(f'[{cmd!r} exited with {proc.returncode}]')
    if proc.returncode == 1:
        return False
    if stdout:
        return f'[stdout]\n{stdout.decode()}'
    if stderr:
        return f'[stderr]\n{stderr.decode()}'

def old_download(url, file_name, chunk_size = 1024 * 10):
    if os.path.exists(file_name):
        os.remove(file_name)
    r = requests.get(url, allow_redirects=True, stream=True)
    with open(file_name, 'wb') as fd:
        for chunk in r.iter_content(chunk_size=chunk_size):
            if chunk:
                fd.write(chunk)
    return file_name

def human_readable_size(size, decimal_places=2):
    for unit in ['B', 'KB', 'MB', 'GB', 'TB', 'PB']:
        if size < 1024.0 or unit == 'PB':
            break
        size /= 1024.0
    return f"{size:.{decimal_places}f} {unit}"

def time_name():
    date = datetime.date.today()
    now = datetime.datetime.now()
    current_time = now.strftime("%H%M%S")
    return f"{date} {current_time}.mp4"

async def download_video(url,cmd, name):
    download_cmd = f'{cmd} -R 25 --fragment-retries 25 --external-downloader aria2c --downloader-args "aria2c: -x 16 -j 32"'
    global failed_counter
    print(download_cmd)
    logging.info(download_cmd)
    k = subprocess.run(download_cmd, shell=True)
    if "visionias" in cmd and k.returncode != 0 and failed_counter <= 10:
        failed_counter += 1
        await asyncio.sleep(5)
        await download_video(url, cmd, name)
    failed_counter = 0
    try:
        if os.path.isfile(name):
            return name
        elif os.path.isfile(f"{name}.webm"):
            return f"{name}.webm"
        name = name.split(".")[0]
        if os.path.isfile(f"{name}.mkv"):
            return f"{name}.mkv"
        elif os.path.isfile(f"{name}.mp4"):
            return f"{name}.mp4"
        elif os.path.isfile(f"{name}.mp4.webm"):
            return f"{name}.mp4.webm"

        return name
    except FileNotFoundError as exc:
        return os.path.isfile.splitext[0] + "." + "mp4"

async def send_doc(bot: Client, m: Message, cc, ka, cc1, prog, count, name):
    reply = await m.reply_text(f"**★彡 Uploading 彡★ ...⏳**\n\n📚𝐓𝐢𝐥𝐥𝐞 » {name}\n\n✦𝐁𝐨𝐭 𝐌𝐚𝐝𝐞 𝐁𝐲 ✦ 𝙄𝙏𝙎𝙂𝙊𝙇𝙐🐦")
    time.sleep(1)
    start_time = time.time()
    await bot.send_document(ka, caption=cc1)
    count+=1
    await reply.delete (True)
    time.sleep(1)
    os.remove(ka)
    time.sleep(3) 

def decrypt_file(file_path, key):  
    if not os.path.exists(file_path): 
        return False  

    with open(file_path, "r+b") as f:  
        num_bytes = min(28, os.path.getsize(file_path))  
        with mmap.mmap(f.fileno(), length=num_bytes, access=mmap.ACCESS_WRITE) as mmapped_file:  
            for i in range(num_bytes):  
                mmapped_file[i] ^= ord(key[i]) if i < len(key) else i 
    return True  

async def download_and_decrypt_video(url, cmd, name, key):  
    video_path = await download_video(url, cmd, name)  
    
    if video_path:  
        decrypted = decrypt_file(video_path, key)  
        if decrypted:  
            print(f"File {video_path} decrypted successfully.")  
            return video_path  
        else:  
            print(f"Failed to decrypt {video_path}.")  
            return None  

async def send_vid(bot: Client, m: Message,cc,filename,thumb,name,prog):
    # Generate thumbnail
    try:
        subprocess.run(f'ffmpeg -i "{filename}" -ss 00:00:10 -vframes 1 "{filename}.jpg"', shell=True, 
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except:
        # If thumbnail generation fails, create a default one
        pass
    
    await prog.delete(True)
    reply = await m.reply_text(f"<b>Generate Thumbnail:</b>\n<blockquote><b>{name}</b></blockquote>")
    
    try:
        if thumb == "/d":
            thumbnail = f"{filename}.jpg"
        else:
            thumbnail = thumb
    except Exception as e:
        await m.reply_text(str(e))
        thumbnail = None
      
    dur = int(duration(filename))
    start_time = time.time()

    try:
        await m.reply_video(
            filename,
            caption=cc,
            supports_streaming=True,
            height=720,
            width=1280,
            thumb=thumbnail,
            duration=dur,
            progress=progress_bar,
            progress_args=(reply, start_time)
        )
    except Exception as e:
        print(f"Video send failed: {e}")
        try:
            await m.reply_document(
                filename,
                caption=cc,
                progress=progress_bar,
                progress_args=(reply, start_time)
            )
        except Exception as e2:
            print(f"Document send failed: {e2}")
            await m.reply_text(f"Failed to send file: {str(e2)}")
    
    finally:
        await reply.delete(True)
        # Clean up files
        try:
            os.remove(filename)
            if thumbnail and os.path.exists(thumbnail):
                os.remove(thumbnail)
        except:
            pass

# New function to process non-DRM content
async def process_non_drm_content(url, path, name, quality):
    try:
        # Determine content type and provide instructions
        # A basic sanitization for the filename/title
        sanitized_title = re.sub(r'[^\w\-_\. ]', '_', url.split('/')[-1].split('.')[0])[:50] or "NonDRM_Content"
        
        # Change to the user's directory
        original_dir = os.getcwd()
        os.chdir(path)
        
        try:
            # Handle specific non-DRM types
            if url.endswith('.m3u8') or 'playlist.m3u8' in url or 'hls' in url.lower():
                # M3U8 Playlist
                yt_dlp_cmd = (
                    f'yt-dlp -o "{sanitized_title}.%(ext)s" '
                    f'-f "bestvideo[height<={quality}]+bestaudio/best[height<={quality}]" '
                    f'--external-downloader aria2c '
                    f'--downloader-args "aria2c: -x 16 -j 32 -s 16 -k 1M --file-allocation=prealloc" '
                    f'--hls-prefer-native '
                    f'--no-check-certificate '
                    f'--no-warnings "{url}"'
                )
            elif url.endswith(('.mp4', '.mov', '.webm', '.avi', '.mkv')):
                # Direct Video File
                yt_dlp_cmd = (
                    f'yt-dlp -o "{sanitized_title}.%(ext)s" '
                    f'--external-downloader aria2c '
                    f'--downloader-args "aria2c: -x 16 -j 32 -s 8 -k 2M" '
                    f'--no-warnings "{url}"'
                )
            elif url.endswith(('.pdf', '.zip', '.docx', '.mp3', '.pptx')):
                # Document/Audio File
                yt_dlp_cmd = f'yt-dlp -o "{sanitized_title}.%(ext)s" --no-warnings "{url}"'
            else:
                # Generic URL
                yt_dlp_cmd = f'yt-dlp -o "{sanitized_title}.%(ext)s" --no-warnings "{url}"'
            
            # Run the download command
            process = await asyncio.create_subprocess_shell(
                yt_dlp_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode == 0:
                # Find the downloaded file
                base_name = sanitized_title.split(".")[0]
                possible_extensions = ['.mp4', '.webm', '.mkv', '.mp3', '.wav', '.m4a', '.pdf']
                
                for ext in possible_extensions:
                    file_path = f"{base_name}{ext}"
                    if os.path.exists(file_path):
                        return os.path.join(path, file_path)
                
                # If not found by exact name, look for any file that starts with base_name
                for file in os.listdir('.'):
                    if file.startswith(base_name) and not file.endswith(('.jpg', '.tmp', '.part')):
                        return os.path.join(path, file)
                
                return None
            else:
                print(f"Download command failed: {stderr.decode()}")
                return None
        finally:
            os.chdir(original_dir)
    except Exception as e:
        print(f"Error processing non-DRM content: {str(e)}")
        return None
