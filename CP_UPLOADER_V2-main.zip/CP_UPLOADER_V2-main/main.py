import os
import aiohttp
import re
import sys
import json
import time
import asyncio
import requests
import subprocess
import tgcrypto
import cloudscraper
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from base64 import b64encode, b64decode
from logs import logging
import itsgolu as helper
from utils import progress_bar
from vars import API_ID, API_HASH, BOT_TOKEN, OWNER, CREDIT, LOG_CHANNEL, API_URL
from aiohttp import ClientSession
from pyromod import listen
from pyrogram import Client, filters
from pyrogram.types import Message, ReplyKeyboardMarkup, ReplyKeyboardRemove
from pyrogram.errors import FloodWait, MessageIdInvalid
import aiofiles
import ffmpeg

# Global dictionary to track stop requests
stop_requests = {}

# Simple HTTP server for health checks
class HealthCheckHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/plain')
        self.end_headers()
        self.wfile.write(b'OK')

def run_http_server():
    server = HTTPServer(('0.0.0.0', 10000), HealthCheckHandler)
    server.serve_forever()

# Start HTTP server in a separate thread
threading.Thread(target=run_http_server, daemon=True).start()

# Initialize bot
bot = Client(
    "bot",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN
)

# Stop keyboard
STOP_KEYBOARD = ReplyKeyboardMarkup([["/stop"]], resize_keyboard=True)

# Helper function to get token from API
async def get_api_token():
    """Get token from API"""
    try:
        response = requests.get(f"{API_URL}/api/get-token", timeout=30)
        if response.status_code == 200:
            token_data = response.json()
            if token_data.get("success"):
                return token_data.get("token")
        return None
    except Exception as e:
        print(f"Error getting token from API: {e}")
        return None

# Helper function to process Classplus URL using API
async def process_classplus_url(url, quality):
    """Process Classplus URL using API"""
    try:
        # Get token from API
        token = await get_api_token()
        
        if not token:
            return None, None
        
        # Process using API
        api_url = f"{API_URL}/api/process-non-drm"
        params = {"url": url, "quality": quality}
        response = requests.get(api_url, params=params, timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            if data.get("success") and "download_instructions" in data:
                instructions = data["download_instructions"]
                return instructions.get("url"), instructions.get("yt_dlp_cmd")
        
        return None, None
    except Exception as e:
        print(f"Error processing Classplus URL: {e}")
        return None, None

@bot.on_message(filters.command(["start"]))
async def start(bot: Client, message: Message):
    await message.reply_text(
        f"👋 Hello! I'm a Classplus Downloader Bot.\n\n"
        f"➠ Use /single to download a single link (DRM, non-DRM, PDF)\n\n"
        f"➠ Use /drm to download Classplus content from .txt files\n\n"
        f"➠ Supports both videos and PDFs\n\n"
        f"➠ Use /stop to cancel any ongoing download\n\n"
        f"➠ Made by: {CREDIT} 🦁"
    )

@bot.on_message(filters.command(["stop"]))
async def stop_handler(bot: Client, message: Message):
    """Handle /stop command to cancel downloads"""
    user_id = message.chat.id
    stop_requests[user_id] = True
    await message.reply_text("🛑 Stop request received. Current download will be cancelled after the current file completes.")

@bot.on_message(filters.command(["single"]))
async def single_handler(bot: Client, m: Message):
    """Handle /single command for downloading a single link"""
    user_id = m.chat.id
    stop_requests[user_id] = False
    
    path = f"./downloads/{user_id}"
    os.makedirs(path, exist_ok=True)
    
    # Get the link
    editable = await m.reply_text("Send me the link to download")
    input_msg = await bot.listen(editable.chat.id)
    url = input_msg.text
    await input_msg.delete(True)
    
    # Get name
    await editable.edit("Enter a name for the file or /d for default")
    try:
        name_msg = await bot.listen(editable.chat.id, timeout=20)
        name = helper.sanitize_filename(name_msg.text if name_msg.text != "/d" else "download")
        await name_msg.delete(True)
    except:
        name = helper.sanitize_filename("download")
    
    # Get quality (for videos)
    await editable.edit("Select video quality: 144, 240, 360, 480, 720, 1080")
    try:
        qual_msg = await bot.listen(editable.chat.id, timeout=20)
        quality = qual_msg.text
        await qual_msg.delete(True)
    except:
        quality = "480"
    
    # Get thumbnail
    await editable.edit("Send thumbnail URL or /d for default")
    try:
        thumb_msg = await bot.listen(editable.chat.id, timeout=20)
        thumb_url = thumb_msg.text
        await thumb_msg.delete(True)
        if thumb_url.startswith("http"):
            subprocess.run(f"wget '{thumb_url}' -O 'thumb.jpg'", shell=True)
            thumb = "thumb.jpg"
        else:
            thumb = "/d"
    except:
        thumb = "/d"
    
    await editable.delete()
    
    # Process the link
    try:
        # Show progress
        prog_text = (
            f"🚀 Processing: {name}\n\n"
            f"🛑 Send /stop to cancel"
        )
        prog_msg = await m.reply_text(prog_text, reply_markup=STOP_KEYBOARD)
        
        # Check if it's a PDF
        if ".pdf" in url.lower():
            await prog_msg.edit_text(f"📄 Downloading PDF: {name}")
            
            # Handle cwmediabkt99 PDFs (not Classplus)
            if "cwmediabkt99" in url:
                max_retries = 15
                retry_delay = 4
                success = False
                
                for attempt in range(max_retries):
                    # Check for stop request during retries
                    if stop_requests.get(user_id, False):
                        await m.reply_text("🛑 PDF download stopped by user.")
                        break
                        
                    try:
                        await asyncio.sleep(retry_delay)
                        url = url.replace(" ", "%20")
                        
                        # Use requests with proper headers for cwmediabkt99
                        headers = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                            'Accept-Language': 'en-US,en;q=0.5',
                            'Accept-Encoding': 'gzip, deflate, br',
                            'Connection': 'keep-alive',
                            'Upgrade-Insecure-Requests': '1',
                            'Referer': url.split('/')[0] + '//' + url.split('/')[2] + '/',
                        }
                        
                        response = requests.get(url, headers=headers, timeout=30, stream=True)
                        
                        if response.status_code == 200:
                            pdf_path = f'{path}/{name}.pdf'
                            with open(pdf_path, 'wb') as file:
                                for chunk in response.iter_content(chunk_size=8192):
                                    # Check for stop request during download
                                    if stop_requests.get(user_id, False):
                                        file.close()
                                        if os.path.exists(pdf_path):
                                            os.remove(pdf_path)
                                        await m.reply_text("🛑 PDF download stopped by user.")
                                        break
                                    if chunk:
                                        file.write(chunk)
                            
                            # Check if we were stopped during download
                            if stop_requests.get(user_id, False):
                                break
                            
                            # Verify PDF is not empty
                            if os.path.getsize(pdf_path) > 0:
                                # Send PDF
                                caption = f"📄 {name}\n⚡ by {CREDIT}"
                                await bot.send_document(
                                    chat_id=m.chat.id,
                                    document=pdf_path,
                                    caption=caption
                                )
                                os.remove(pdf_path)
                                success = True
                                break
                            else:
                                os.remove(pdf_path)
                                raise Exception("Downloaded PDF is empty")
                        else:
                            raise Exception(f"HTTP {response.status_code}")
                            
                    except Exception as e:
                        await m.reply_text(
                            f"Attempt {attempt + 1}/{max_retries} failed: {str(e)}"
                        )
                        await asyncio.sleep(retry_delay)
                        continue
                
                if not success and not stop_requests.get(user_id, False):
                    await m.reply_text(f"❌ Failed to download PDF after {max_retries} attempts")
            
            # Handle Classplus PDFs
            elif "classplusapp.com" in url:
                # Get token from API
                token = await get_api_token()
                
                if not token:
                    await m.reply_text("❌ Failed to generate token for Classplus PDF download")
                    return
                
                headers = {
                    'x-access-token': token,
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                }
                
                response = requests.get(url, headers=headers, stream=True)
                if response.status_code == 200:
                    pdf_path = f'{path}/{name}.pdf'
                    with open(pdf_path, 'wb') as file:
                        for chunk in response.iter_content(chunk_size=8192):
                            # Check for stop request during download
                            if stop_requests.get(user_id, False):
                                file.close()
                                if os.path.exists(pdf_path):
                                    os.remove(pdf_path)
                                await m.reply_text("🛑 PDF download stopped by user.")
                                break
                            if chunk:
                                file.write(chunk)
                    
                    # Check if we were stopped during download
                    if stop_requests.get(user_id, False):
                        pass
                    else:
                        # Send PDF
                        caption = f"📄 {name}\n⚡ by {CREDIT}"
                        await bot.send_document(
                            chat_id=m.chat.id,
                            document=pdf_path,
                            caption=caption
                        )
                        os.remove(pdf_path)
                else:
                    await m.reply_text(f"❌ PDF download failed: HTTP {response.status_code}")
            
            # Regular PDF download
            else:
                pdf_path = f'{path}/{name}.pdf'
                cmd = f'yt-dlp -o "{pdf_path}" "{url}"'
                os.system(cmd)
                
                if os.path.exists(pdf_path) and os.path.getsize(pdf_path) > 0:
                    caption = f"📄 {name}\n⚡ by {CREDIT}"
                    await bot.send_document(
                        chat_id=m.chat.id,
                        document=pdf_path,
                        caption=caption
                    )
                    os.remove(pdf_path)
                else:
                    await m.reply_text(f"❌ PDF download failed")
                    
        # Process Classplus Videos
        elif "cpvod.testbook.com/" in url or "classplusapp.com/" in url:
            try:
                await prog_msg.edit_text(f"🎬 Processing video: {name}")
            except MessageIdInvalid:
                prog_msg = await m.reply_text(f"🎬 Processing video: {name}", reply_markup=STOP_KEYBOARD)
            
            if "cpvod.testbook.com/" in url:
                url = url.replace("https://cpvod.testbook.com/", "https://media-cdn.classplusapp.com/drm/")
            
            # Check if it's DRM or Non-DRM
            if "drm/" in url:
                # Process DRM URLs using API
                try:
                    api_url = f"{API_URL}/v1/api"
                    params = {"url": url}
                    response = requests.get(api_url, params=params, timeout=30)
                    
                    if response.status_code == 200:
                        data = response.json()
                        if data.get("success") and data.get("url"):
                            url = data["url"]
                            try:
                                await prog_msg.edit_text("✅ DRM URL processed")
                            except MessageIdInvalid:
                                prog_msg = await m.reply_text("✅ DRM URL processed", reply_markup=STOP_KEYBOARD)
                        else:
                            await m.reply_text(f"❌ API Error: {data.get('error', 'Unknown')}")
                            return
                    else:
                        await m.reply_text(f"❌ API Failed: {response.status}")
                        return
                except Exception as e:
                    await m.reply_text(f"❌ API Exception: {str(e)}")
                    return
                
                # Download video
                res_file = await helper.decrypt_and_merge_video(url, "", path, name, quality)
            else:
                # Process Non-DRM Classplus URLs using API
                processed_url, yt_dlp_cmd = await process_classplus_url(url, quality)
                
                if processed_url and yt_dlp_cmd:
                    url = processed_url
                    try:
                        await prog_msg.edit_text("✅ Non-DRM URL processed")
                    except MessageIdInvalid:
                        prog_msg = await m.reply_text("✅ Non-DRM URL processed", reply_markup=STOP_KEYBOARD)
                else:
                    await m.reply_text(f"❌ Failed to process Non-DRM URL")
                    return
                
                # Download video
                res_file = await helper.download_video(url, yt_dlp_cmd, name)
            
            # Check if we were stopped during download
            if stop_requests.get(user_id, False):
                await m.reply_text("🛑 Video download stopped by user.")
                pass
            else:
                # Send video
                caption = f"📹 {name}\n🎬 {quality}p\n⚡ by {CREDIT}"
                await helper.send_vid(bot, m, caption, res_file, thumb, name, prog_msg)
        
        # Handle non-DRM video content
        elif url.endswith(('.mp4', '.mov', '.webm', '.avi', '.mkv', '.m3u8')) or 'playlist.m3u8' in url:
            try:
                await prog_msg.edit_text(f"🎬 Processing non-DRM video: {name}")
            except MessageIdInvalid:
                prog_msg = await m.reply_text(f"🎬 Processing non-DRM video: {name}", reply_markup=STOP_KEYBOARD)
            
            # Use API to process Non-DRM content
            processed_url, yt_dlp_cmd = await process_classplus_url(url, quality)
            
            if processed_url and yt_dlp_cmd:
                # Change to the user's directory
                original_dir = os.getcwd()
                os.chdir(path)
                
                try:
                    # Run the download command
                    process = await asyncio.create_subprocess_shell(
                        yt_dlp_cmd,
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    stdout, stderr = await process.communicate()
                    
                    if process.returncode == 0:
                        # Find the downloaded file
                        base_name = name.split(".")[0]
                        possible_extensions = ['.mp4', '.webm', '.mkv', '.mp3', '.wav', '.m4a', '.pdf']
                        
                        for ext in possible_extensions:
                            file_path = f"{base_name}{ext}"
                            if os.path.exists(file_path):
                                res_file = os.path.join(path, file_path)
                                break
                        
                        # If not found by exact name, look for any file that starts with base_name
                        if not res_file:
                            for file in os.listdir('.'):
                                if file.startswith(base_name) and not file.endswith(('.jpg', '.tmp', '.part')):
                                    res_file = os.path.join(path, file)
                                    break
                    else:
                        res_file = None
                finally:
                    os.chdir(original_dir)
            else:
                await m.reply_text(f"❌ Download command failed")
                res_file = None
            
            if res_file:
                # Send video
                caption = f"📹 {name}\n🎬 {quality}p\n⚡ by {CREDIT}"
                await helper.send_vid(bot, m, caption, res_file, thumb, name, prog_msg)
            else:
                await m.reply_text(f"❌ Failed to download non-DRM video")
        
        # Handle audio content
        elif url.endswith(('.mp3', '.wav', '.m4a')):
            try:
                await prog_msg.edit_text(f"🎵 Processing audio: {name}")
            except MessageIdInvalid:
                prog_msg = await m.reply_text(f"🎵 Processing audio: {name}", reply_markup=STOP_KEYBOARD)
            
            # Use API to process Non-DRM content
            processed_url, yt_dlp_cmd = await process_classplus_url(url, quality)
            
            if processed_url and yt_dlp_cmd:
                # Change to the user's directory
                original_dir = os.getcwd()
                os.chdir(path)
                
                try:
                    # Run the download command
                    process = await asyncio.create_subprocess_shell(
                        yt_dlp_cmd,
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    stdout, stderr = await process.communicate()
                    
                    if process.returncode == 0:
                        # Find the downloaded file
                        base_name = name.split(".")[0]
                        possible_extensions = ['.mp4', '.webm', '.mkv', '.mp3', '.wav', '.m4a', '.pdf']
                        
                        for ext in possible_extensions:
                            file_path = f"{base_name}{ext}"
                            if os.path.exists(file_path):
                                res_file = os.path.join(path, file_path)
                                break
                        
                        # If not found by exact name, look for any file that starts with base_name
                        if not res_file:
                            for file in os.listdir('.'):
                                if file.startswith(base_name) and not file.endswith(('.jpg', '.tmp', '.part')):
                                    res_file = os.path.join(path, file)
                                    break
                    else:
                        res_file = None
                finally:
                    os.chdir(original_dir)
            else:
                await m.reply_text(f"❌ Download command failed")
                res_file = None
            
            if res_file:
                # Send audio
                caption = f"🎵 {name}\n⚡ by {CREDIT}"
                await bot.send_audio(
                    chat_id=m.chat.id,
                    audio=res_file,
                    caption=caption,
                    thumb=thumb
                )
                os.remove(res_file)
            else:
                await m.reply_text(f"❌ Failed to download audio")
        
        # Skip other URLs
        else:
            try:
                await prog_msg.edit_text(f"⏭️ Skipping unsupported URL")
            except MessageIdInvalid:
                prog_msg = await m.reply_text(f"⏭️ Skipping unsupported URL", reply_markup=STOP_KEYBOARD)
            await asyncio.sleep(1)
            
    except Exception as e:
        await m.reply_text(f"❌ Download failed: {str(e)}")
    
    # Clear the stop request for this user
    stop_requests[user_id] = False

@bot.on_message(filters.command(["drm"]))
async def drm_handler(bot: Client, m: Message):
    # Clear any previous stop request for this user
    user_id = m.chat.id
    stop_requests[user_id] = False
    
    path = f"./downloads/{user_id}"
    os.makedirs(path, exist_ok=True)
    
    # Get txt file
    editable = await m.reply_text("Send me the txt file with Classplus links")
    input_msg = await bot.listen(editable.chat.id)
    file_path = await input_msg.download()
    await input_msg.delete(True)
    file_name = os.path.splitext(os.path.basename(file_path))[0]
    
    # Process file
    try:
        with open(file_path, "r") as f:
            content = f.read().split("\n")
        links = [line.split("://", 1) for line in content if "://" in line]
        os.remove(file_path)
    except Exception as e:
        await m.reply_text(f"Invalid file: {str(e)}")
        return
    
    # Get starting index
    await editable.edit(f"Found {len(links)} links. Where to start? (1-{len(links)})")
    try:
        start_msg = await bot.listen(editable.chat.id, timeout=20)
        start_idx = int(start_msg.text) - 1
        await start_msg.delete(True)
    except:
        start_idx = 0
    
    # Get batch name
    await editable.edit("Enter batch name or /d for default")
    try:
        name_msg = await bot.listen(editable.chat.id, timeout=20)
        batch_name = helper.sanitize_filename(name_msg.text if name_msg.text != "/d" else file_name)
        await name_msg.delete(True)
    except:
        batch_name = helper.sanitize_filename(file_name)
    
    # Get quality (for videos)
    await editable.edit("Select video quality: 144, 240, 360, 480, 720, 1080")
    try:
        qual_msg = await bot.listen(editable.chat.id, timeout=20)
        quality = qual_msg.text
        await qual_msg.delete(True)
    except:
        quality = "480"
    
    # Get thumbnail
    await editable.edit("Send thumbnail URL or /d for default")
    try:
        thumb_msg = await bot.listen(editable.chat.id, timeout=20)
        thumb_url = thumb_msg.text
        await thumb_msg.delete(True)
        if thumb_url.startswith("http"):
            subprocess.run(f"wget '{thumb_url}' -O 'thumb.jpg'", shell=True)
            thumb = "thumb.jpg"
        else:
            thumb = "/d"
    except:
        thumb = "/d"
    
    await editable.delete()
    
    # Process links
    failed = 0
    pdf_count = 0
    video_count = 0
    
    # Initialize progress message outside the loop
    prog_msg = None
    
    for i in range(start_idx, len(links)):
        # Check if user requested to stop
        if stop_requests.get(user_id, False):
            await m.reply_text("🛑 Download stopped by user.")
            # Clear the stop request
            stop_requests[user_id] = False
            break
        
        try:
            count = i + 1
            url = "https://" + links[i][1].replace("file/d/", "uc?export=download&id=")
            name = helper.sanitize_filename(links[i][0][:60])
            
            # Show progress
            progress = (count / len(links)) * 100
            remaining = len(links) - count
            prog_text = (
                f"🚀 Progress: {progress:.1f}%\n"
                f"📊 Index: {count}/{len(links)}\n"
                f"⏳ Remaining: {remaining}\n\n"
                f"⚡ Processing: {name}\n"
                f"📁 Batch: {batch_name}\n\n"
                f"🛑 Send /stop to cancel"
            )
            
            # Try to edit existing progress message or send a new one
            try:
                if prog_msg:
                    await prog_msg.edit_text(prog_text)
                else:
                    prog_msg = await m.reply_text(prog_text, reply_markup=STOP_KEYBOARD)
            except MessageIdInvalid:
                prog_msg = await m.reply_text(prog_text, reply_markup=STOP_KEYBOARD)
            
            # Check if it's a PDF
            if ".pdf" in url.lower():
                pdf_count += 1
                try:
                    await prog_msg.edit_text(f"📄 Downloading PDF: {name}")
                except MessageIdInvalid:
                    prog_msg = await m.reply_text(f"📄 Downloading PDF: {name}", reply_markup=STOP_KEYBOARD)
                
                # Handle cwmediabkt99 PDFs (not Classplus)
                if "cwmediabkt99" in url:
                    max_retries = 15
                    retry_delay = 4
                    success = False
                    failure_msgs = []
                    
                    for attempt in range(max_retries):
                        # Check for stop request during retries
                        if stop_requests.get(user_id, False):
                            await m.reply_text("🛑 PDF download stopped by user.")
                            break
                            
                        try:
                            await asyncio.sleep(retry_delay)
                            url = url.replace(" ", "%20")
                            
                            # Use requests with proper headers for cwmediabkt99
                            headers = {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Accept-Encoding': 'gzip, deflate, br',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                                'Referer': url.split('/')[0] + '//' + url.split('/')[2] + '/',
                            }
                            
                            response = requests.get(url, headers=headers, timeout=30, stream=True)
                            
                            if response.status_code == 200:
                                pdf_path = f'{path}/{name}.pdf'
                                with open(pdf_path, 'wb') as file:
                                    for chunk in response.iter_content(chunk_size=8192):
                                        # Check for stop request during download
                                        if stop_requests.get(user_id, False):
                                            file.close()
                                            if os.path.exists(pdf_path):
                                                os.remove(pdf_path)
                                            await m.reply_text("🛑 PDF download stopped by user.")
                                            break
                                        if chunk:
                                            file.write(chunk)
                                
                                # Check if we were stopped during download
                                if stop_requests.get(user_id, False):
                                    break
                                
                                # Verify PDF is not empty
                                if os.path.getsize(pdf_path) > 0:
                                    # Send PDF
                                    caption = f"📄 {name}\n📚 {batch_name}\n⚡ by {CREDIT}"
                                    await bot.send_document(
                                        chat_id=m.chat.id,
                                        document=pdf_path,
                                        caption=caption
                                    )
                                    os.remove(pdf_path)
                                    success = True
                                    break
                                else:
                                    os.remove(pdf_path)
                                    raise Exception("Downloaded PDF is empty")
                            else:
                                raise Exception(f"HTTP {response.status_code}")
                                
                        except Exception as e:
                            failure_msg = await m.reply_text(
                                f"Attempt {attempt + 1}/{max_retries} failed: {str(e)}"
                            )
                            failure_msgs.append(failure_msg)
                            await asyncio.sleep(retry_delay)
                            continue
                    
                    # Clean up failure messages
                    for msg in failure_msgs:
                        await msg.delete()
                    
                    if not success and not stop_requests.get(user_id, False):
                        await m.reply_text(f"❌ Failed to download PDF after {max_retries} attempts")
                        failed += 1
                
                # Handle Classplus PDFs
                elif "classplusapp.com" in url:
                    # Get token from API
                    token = await get_api_token()
                    
                    if not token:
                        await m.reply_text("❌ Failed to generate token for Classplus PDF download")
                        failed += 1
                        continue
                    
                    headers = {
                        'x-access-token': token,
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                    }
                    
                    response = requests.get(url, headers=headers, stream=True)
                    if response.status_code == 200:
                        pdf_path = f'{path}/{name}.pdf'
                        with open(pdf_path, 'wb') as file:
                            for chunk in response.iter_content(chunk_size=8192):
                                # Check for stop request during download
                                if stop_requests.get(user_id, False):
                                    file.close()
                                    if os.path.exists(pdf_path):
                                        os.remove(pdf_path)
                                    await m.reply_text("🛑 PDF download stopped by user.")
                                    break
                                if chunk:
                                    file.write(chunk)
                        
                        # Check if we were stopped during download
                        if stop_requests.get(user_id, False):
                            break
                        
                        # Send PDF
                        caption = f"📄 {name}\n📚 {batch_name}\n⚡ by {CREDIT}"
                        await bot.send_document(
                            chat_id=m.chat.id,
                            document=pdf_path,
                            caption=caption
                        )
                        os.remove(pdf_path)
                    else:
                        await m.reply_text(f"❌ PDF download failed: HTTP {response.status_code}")
                        failed += 1
                
                # Regular PDF download
                else:
                    pdf_path = f'{path}/{name}.pdf'
                    cmd = f'yt-dlp -o "{pdf_path}" "{url}"'
                    os.system(cmd)
                    
                    if os.path.exists(pdf_path) and os.path.getsize(pdf_path) > 0:
                        caption = f"📄 {name}\n📚 {batch_name}\n⚡ by {CREDIT}"
                        await bot.send_document(
                            chat_id=m.chat.id,
                            document=pdf_path,
                            caption=caption
                        )
                        os.remove(pdf_path)
                    else:
                        await m.reply_text(f"❌ PDF download failed")
                        failed += 1
                        
            # Process Classplus Videos
            elif "cpvod.testbook.com/" in url or "classplusapp.com/" in url:
                video_count += 1
                try:
                    await prog_msg.edit_text(f"🎬 Processing video: {name}")
                except MessageIdInvalid:
                    prog_msg = await m.reply_text(f"🎬 Processing video: {name}", reply_markup=STOP_KEYBOARD)
                
                if "cpvod.testbook.com/" in url:
                    url = url.replace("https://cpvod.testbook.com/", "https://media-cdn.classplusapp.com/drm/")
                
                # Check if it's DRM or Non-DRM
                if "drm/" in url:
                    # Process DRM URLs using API
                    try:
                        api_url = f"{API_URL}/v1/api"
                        params = {"url": url}
                        response = requests.get(api_url, params=params, timeout=30)
                        
                        if response.status_code == 200:
                            data = response.json()
                            if data.get("success") and data.get("url"):
                                url = data["url"]
                                try:
                                    await prog_msg.edit_text("✅ DRM URL processed")
                                except MessageIdInvalid:
                                    prog_msg = await m.reply_text("✅ DRM URL processed", reply_markup=STOP_KEYBOARD)
                            else:
                                await m.reply_text(f"❌ API Error: {data.get('error', 'Unknown')}")
                                failed += 1
                                continue
                        else:
                            await m.reply_text(f"❌ API Failed: {response.status}")
                            failed += 1
                            continue
                    except Exception as e:
                        await m.reply_text(f"❌ API Exception: {str(e)}")
                        failed += 1
                        continue
                    
                    # Download video
                    res_file = await helper.decrypt_and_merge_video(url, "", path, name, quality)
                else:
                    # Process Non-DRM Classplus URLs using API
                    processed_url, yt_dlp_cmd = await process_classplus_url(url, quality)
                    
                    if processed_url and yt_dlp_cmd:
                        url = processed_url
                        try:
                            await prog_msg.edit_text("✅ Non-DRM URL processed")
                        except MessageIdInvalid:
                            prog_msg = await m.reply_text("✅ Non-DRM URL processed", reply_markup=STOP_KEYBOARD)
                    else:
                        await m.reply_text(f"❌ Failed to process Non-DRM URL")
                        failed += 1
                        continue
                    
                    # Download video
                    res_file = await helper.download_video(url, yt_dlp_cmd, name)
                
                # Check if we were stopped during download
                if stop_requests.get(user_id, False):
                    await m.reply_text("🛑 Video download stopped by user.")
                    break
                
                # Send video
                caption = f"📹 {name}\n🎬 {quality}p\n📚 {batch_name}\n⚡ by {CREDIT}"
                await helper.send_vid(bot, m, caption, res_file, thumb, name, prog_msg)
            
            # Handle non-DRM video content
            elif url.endswith(('.mp4', '.mov', '.webm', '.avi', '.mkv', '.m3u8')) or 'playlist.m3u8' in url:
                video_count += 1
                try:
                    await prog_msg.edit_text(f"🎬 Processing non-DRM video: {name}")
                except MessageIdInvalid:
                    prog_msg = await m.reply_text(f"🎬 Processing non-DRM video: {name}", reply_markup=STOP_KEYBOARD)
                
                # Use API to process Non-DRM content
                processed_url, yt_dlp_cmd = await process_classplus_url(url, quality)
                
                if processed_url and yt_dlp_cmd:
                    # Change to the user's directory
                    original_dir = os.getcwd()
                    os.chdir(path)
                    
                    try:
                        # Run the download command
                        process = await asyncio.create_subprocess_shell(
                            yt_dlp_cmd,
                            stdout=asyncio.subprocess.PIPE,
                            stderr=asyncio.subprocess.PIPE
                        )
                        stdout, stderr = await process.communicate()
                        
                        if process.returncode == 0:
                            # Find the downloaded file
                            base_name = name.split(".")[0]
                            possible_extensions = ['.mp4', '.webm', '.mkv', '.mp3', '.wav', '.m4a', '.pdf']
                            
                            for ext in possible_extensions:
                                file_path = f"{base_name}{ext}"
                                if os.path.exists(file_path):
                                    res_file = os.path.join(path, file_path)
                                    break
                            
                            # If not found by exact name, look for any file that starts with base_name
                            if not res_file:
                                for file in os.listdir('.'):
                                    if file.startswith(base_name) and not file.endswith(('.jpg', '.tmp', '.part')):
                                        res_file = os.path.join(path, file)
                                        break
                        else:
                            res_file = None
                    finally:
                        os.chdir(original_dir)
                else:
                    await m.reply_text(f"❌ Download command failed")
                    res_file = None
                
                if res_file:
                    # Send video
                    caption = f"📹 {name}\n🎬 {quality}p\n📚 {batch_name}\n⚡ by {CREDIT}"
                    await helper.send_vid(bot, m, caption, res_file, thumb, name, prog_msg)
                else:
                    await m.reply_text(f"❌ Failed to download non-DRM video")
                    failed += 1
            
            # Handle audio content
            elif url.endswith(('.mp3', '.wav', '.m4a')):
                video_count += 1
                try:
                    await prog_msg.edit_text(f"🎵 Processing audio: {name}")
                except MessageIdInvalid:
                    prog_msg = await m.reply_text(f"🎵 Processing audio: {name}", reply_markup=STOP_KEYBOARD)
                
                # Use API to process Non-DRM content
                processed_url, yt_dlp_cmd = await process_classplus_url(url, quality)
                
                if processed_url and yt_dlp_cmd:
                    # Change to the user's directory
                    original_dir = os.getcwd()
                    os.chdir(path)
                    
                    try:
                        # Run the download command
                        process = await asyncio.create_subprocess_shell(
                            yt_dlp_cmd,
                            stdout=asyncio.subprocess.PIPE,
                            stderr=asyncio.subprocess.PIPE
                        )
                        stdout, stderr = await process.communicate()
                        
                        if process.returncode == 0:
                            # Find the downloaded file
                            base_name = name.split(".")[0]
                            possible_extensions = ['.mp4', '.webm', '.mkv', '.mp3', '.wav', '.m4a', '.pdf']
                            
                            for ext in possible_extensions:
                                file_path = f"{base_name}{ext}"
                                if os.path.exists(file_path):
                                    res_file = os.path.join(path, file_path)
                                    break
                            
                            # If not found by exact name, look for any file that starts with base_name
                            if not res_file:
                                for file in os.listdir('.'):
                                    if file.startswith(base_name) and not file.endswith(('.jpg', '.tmp', '.part')):
                                        res_file = os.path.join(path, file)
                                        break
                        else:
                            res_file = None
                    finally:
                        os.chdir(original_dir)
                else:
                    await m.reply_text(f"❌ Download command failed")
                    res_file = None
                
                if res_file:
                    # Send audio
                    caption = f"🎵 {name}\n📚 {batch_name}\n⚡ by {CREDIT}"
                    await bot.send_audio(
                        chat_id=m.chat.id,
                        audio=res_file,
                        caption=caption,
                        thumb=thumb
                    )
                    os.remove(res_file)
                else:
                    await m.reply_text(f"❌ Failed to download audio")
                    failed += 1
            
            # Skip other URLs
            else:
                try:
                    await prog_msg.edit_text(f"⏭️ Skipping non-Classplus URL")
                except MessageIdInvalid:
                    prog_msg = await m.reply_text(f"⏭️ Skipping non-Classplus URL", reply_markup=STOP_KEYBOARD)
                await asyncio.sleep(1)
                continue
                
        except Exception as e:
            await m.reply_text(f"❌ Download failed: {str(e)}")
            failed += 1
    
    # Final summary
    await m.reply_text(
        f"✅ Download completed!\n\n"
        f"📊 Total links: {len(links)}\n"
        f"📄 PDFs downloaded: {pdf_count}\n"
        f"🎬 Videos downloaded: {video_count}\n"
        f"❌ Failed: {failed}",
        reply_markup=ReplyKeyboardRemove()
    )
    
    # Clear the stop request for this user
    stop_requests[user_id] = False

bot.run()
