
## Deploy Via Buttons

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://www.heroku.com/deploy?template=https://github.com/mrgadhvii-os/UGxUploaderv2.git)


