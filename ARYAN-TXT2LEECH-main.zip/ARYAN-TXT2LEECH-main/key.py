import requests
import logging
import xml.etree.ElementTree as ET
import sys
import getopt
from vars import TOKEN
# 🔹 Setup basic logging configuration
logging.basicConfig(
    format="%(message)s",  # Only output the message itself
    level=logging.ERROR  # Default level is ERROR (no verbose logs)
)

verbose = False  # Default to non-verbose mode

# Parse command-line arguments
def parse_args():
    global verbose
    try:
        opts, args = getopt.getopt(sys.argv[1:], "v")
        for opt, _ in opts:
            if opt == "-v":
                verbose = True  # Enable verbose mode
    except getopt.GetoptError as err:
        logging.error("Error parsing arguments.")
        sys.exit(1)

# 🔹 Fetch MPD manifest from URL and return the response content
def fetch_mpd(mpd_url):
    try:
        response = requests.get(mpd_url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}, timeout=10)
        response.raise_for_status()
        if verbose:
            logging.debug(f"Fetched MPD Manifest: {mpd_url}")
        return response.text
    except requests.exceptions.RequestException:
        return None

# 🔹 Extract PSSH from MPD manifest
def extract_pssh_from_mpd(mpd_url):
    mpd_content = fetch_mpd(mpd_url)
    if not mpd_content:
        return None

    ns = {"dash": "urn:mpeg:dash:schema:mpd:2011", "cenc": "urn:mpeg:cenc:2013"}
    try:
        root = ET.fromstring(mpd_content)
    except ET.ParseError:
        return None

    pssh_list = []
    for elem in root.findall(".//dash:ContentProtection", ns):
        pssh_elem = elem.find("cenc:pssh", ns)
        if pssh_elem is not None and pssh_elem.text:
            pssh = pssh_elem.text.strip()
            if pssh not in pssh_list:  # Avoid duplicates
                pssh_list.append(pssh)

    return pssh_list if pssh_list else None

# 🔹 Fetch decryption keys
def fetch_decryption_keys(pssh_list, license_url):
    for pssh in pssh_list:
        payload = {"pssh": pssh, "licurl": license_url, "headers": "{}"}
        response = requests.post("https://cdrm-project.com/api/decrypt", json=payload)

        if response.status_code == 200:
            keys = response.json().get("message", "")
            if keys:
                # Write keys to a file
                with open("keys.txt", "a") as key_file:
                    key_file.write(keys + "\n")
                if verbose:
                    logging.debug(f"Decryption keys: {keys}")
                return keys
    return None

# 🔹 Process URL (main logic)
def process_url(url):
    response = requests.get(
        f'https://api.classplusapp.com/cams/uploader/video/jw-signed-url?contentId={url}',
        headers={'x-access-token': TOKEN}
    ).json()

    # If URL is present in the response
    if "url" in response and response["url"]:
        if verbose:
            logging.debug(f"Direct video URL found: {response['url']}")
        return response["url"]

    # If DRM URLs are present
    if "drmUrls" in response and "manifestUrl" in response["drmUrls"] and "licenseUrl" in response["drmUrls"]:
        manifest_url = response["drmUrls"]["manifestUrl"]
        license_url = response["drmUrls"]["licenseUrl"]

        if verbose:
            logging.debug(f"DRM detected. Manifest URL: {manifest_url}, License URL: {license_url}")

        pssh_list = extract_pssh_from_mpd(manifest_url)
        if pssh_list:
            keys = fetch_decryption_keys(pssh_list, license_url)
            if keys:
                return manifest_url  # Return manifest URL after processing
        else:
            if verbose:
                logging.debug("No PSSH found in MPD.")
    return None

# Main function
def main():
    # Parse the arguments
    parse_args()

    # Get URL passed as argument
    if len(sys.argv) < 2:
        logging.error("No URL passed.")
        sys.exit(1)

    url = sys.argv[1]
    final_url = process_url(url)

    if final_url:
        print(final_url)  # This will be the final URL printed (either direct URL or manifest URL)
    else:
        sys.exit(1)

if __name__ == "__main__":
    main()
