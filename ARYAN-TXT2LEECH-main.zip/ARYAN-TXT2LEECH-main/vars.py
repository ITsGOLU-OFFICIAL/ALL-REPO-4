# Don't Remove Credit Tg - @VJ_Botz
# Subscribe YouTube Channel For Amazing Bot https://youtube.com/@Tech_VJ
# Ask Doubt on telegram @KingVJ01

from os import environ

API_ID = int(environ.get("API_ID", "21072440"))
API_HASH = environ.get("API_HASH", "34de6b48b3d41aabf501a061ff7bc6c9")
BOT_TOKEN = environ.get("BOT_TOKEN", "8144193784:AAFSHws8_yqoZ0k-9MsWt_-Zvs8QPiN-0ZY")
AUTHORIZED_CHATS = ["2131377350", "7507697121", "-4770405634"] 
TOKEN = environ.get("TOKEN", "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJpZCI6MTU0MTA1MjI3LCJvcmdJZCI6MjI5MCwidHlwZSI6MSwibW9iaWxlIjoiOTE4MjEwNzExODk1IiwibmFtZSI6IkFkaXR5YSIsImVtYWlsIjoiYTg3MDYzMTIwQGdtYWlsLmNvbSIsImlzSW50ZXJuYXRpb25hbCI6MCwiZGVmYXVsdExhbmd1YWdlIjoiRU4iLCJjb3VudHJ5Q29kZSI6IklOIiwiY291bnRyeUlTTyI6IjkxIiwidGltZXpvbmUiOiJHTVQrNTozMCIsImlzRGl5Ijp0cnVlLCJvcmdDb2RlIjoidGd0YSIsImlzRGl5U3ViYWRtaW4iOjAsImZpbmdlcnByaW50SWQiOiI0OTEzY2YyNzc4ZmQ0ZDUyMDYzOWFhYjQ0ZTVjNjQxYiIsImlhdCI6MTc1MjQ4MzkwNSwiZXhwIjoxNzUzMDg4NzA1fQ.kZy_nZL2a9vAeWQmDohTel3J-mSay6l3jyXgBrn14n99Wz_L427PbyTHyiPxAMWM")
AUTH = environ.get("AUTH", "")
UUID = environ.get("UUID", "")
