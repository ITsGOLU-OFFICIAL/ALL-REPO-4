#import asyncio
#import uvloop
#asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())

import os
import re
import sys
import json
import time

import requests
import subprocess
import uvloop
import core as helper
from utils import progress_bar
from vars import API_ID, API_HASH, BOT_TOKEN, AUTHORIZED_CHATS, AUTH, UUID, TOKEN
from aiohttp import ClientSession
from pyromod import listen
from subprocess import getstatusoutput

from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup
from pyrogram.errors import FloodWait

from pyrogram.errors.exceptions.bad_request_400 import StickerEmojiInvalid
import hmac
import hashlib
from pyrogram.enums import ParseMode
import xml.etree.ElementTree as ET
import logging
from aiohttp import web

bot = Client(
    "bot",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN
)

# Signature generation function
def generate_signature(data, secret_key):
    return hmac.new(secret_key.encode(), data.encode(), hashlib.sha256).hexdigest()

# Check if chat is authorized
def is_authorized(chat_id):
    return str(chat_id) in AUTHORIZED_CHATS

def fetch_mpd(mpd_url, verbose=False):
    try:
        response = requests.get(
            mpd_url,
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"},
            timeout=10,
        )
        response.raise_for_status()
        if verbose:
            logger.debug(f"Fetched MPD Manifest: {mpd_url}")
        return response.text
    except requests.exceptions.RequestException as e:
        if verbose:
            logger.debug(f"Failed to fetch MPD: {e}")
        return None

def extract_pssh_from_mpd(mpd_url, verbose=False):
    mpd_content = fetch_mpd(mpd_url, verbose)
    if not mpd_content:
        return None

    ns = {"dash": "urn:mpeg:dash:schema:mpd:2011", "cenc": "urn:mpeg:cenc:2013"}
    try:
        root = ET.fromstring(mpd_content)
    except ET.ParseError:
        if verbose:
            logger.debug("Failed to parse MPD XML")
        return None

    pssh_list = []
    for elem in root.findall(".//dash:ContentProtection", ns):
        pssh_elem = elem.find("cenc:pssh", ns)
        if pssh_elem is not None and pssh_elem.text:
            pssh = pssh_elem.text.strip()
            if pssh not in pssh_list:
                pssh_list.append(pssh)

    return pssh_list if pssh_list else None

def fetch_decryption_keys(pssh_list, license_url, verbose=False):
    for pssh in pssh_list:
        payload = {"pssh": pssh, "licurl": license_url, "headers": str({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})}
        try:
            response = requests.post("https://cdrm-project.com/api/decrypt", json=payload)
            response.raise_for_status()
            keys = response.json().get("message", "")
            if keys:
                with open("keys.txt", "w") as key_file:
                    key_file.write(keys + "\n")
                if verbose:
                    logger.debug(f"Decryption keys: {keys}")
                return keys
        except requests.RequestException as e:
            if verbose:
                logger.debug(f"Failed to fetch keys: {e}")
    return None

def process_url(url, verbose=False):
    try:
        response = requests.get(
            f'https://api.classplusapp.com/cams/uploader/video/jw-signed-url?contentId={url}',
            headers={'x-access-token': TOKEN}
        )
        response.raise_for_status()
        data = response.json()
    except requests.RequestException as e:
        if verbose:
            logger.debug(f"API request failed: {e}")
        return None

    if "url" in data and data["url"]:
        if verbose:
            logger.debug(f"Direct video URL found: {data['url']}")
        return data["url"]

    if "drmUrls" in data and "manifestUrl" in data["drmUrls"] and "licenseUrl" in data["drmUrls"]:
        manifest_url = data["drmUrls"]["manifestUrl"]
        license_url = data["drmUrls"]["licenseUrl"]

        if verbose:
            logger.debug(f"DRM detected. Manifest URL: {manifest_url}, License URL: {license_url}")

        pssh_list = extract_pssh_from_mpd(manifest_url, verbose)
        if pssh_list:
            keys = fetch_decryption_keys(pssh_list, license_url, verbose)
            if keys:
                return manifest_url
        else:
            if verbose:
                logger.debug("No PSSH found in MPD.")
    return None


 
@bot.on_message(filters.command(["start"]))
async def start(bot: Client, m: Message):
    if not is_authorized(m.chat.id):
        await m.reply_text(
            "🚫 <b>Access Denied!</b>\n\n"
            "This bot is <b>restricted</b> to authorized users only. 🔒\n\n"
            "💡 <b>What is this bot?</b>\n"
            "This is a <b>TXT2Leech bot</b> that helps you extract and download links from "
            "<code>.TXT</code> files 📄 and supports various platforms like <b>PW, Classplus, and more</b>! 🚀\n\n"
            "If you need access to our services, please contact the bot owner. 📩\n\n"
            "📞 <b>Request Access Below:</b>",
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("📞 Contact Owner", url="https://t.me/aryan_patel_99")]]
            ),
            parse_mode=ParseMode.HTML
        )
        return

    await m.reply_text(
        f"👋 <b>Welcome, {m.from_user.mention}!</b>\n\n"
        "🚀 <b>I'm your personal assistant bot, designed to make your life easier!</b>\n"
        "I help you extract and process download links from <code>.TXT</code> files 📄 "
        "and then upload the processed files directly to Telegram! 📤\n\n"
        "<b>🎯 How to Get Started?</b>\n"
        "1 Send <code>/upload</code> to start processing your file.\n"
        "2 Follow the prompts to complete the process.\n"
        "3 Use <code>/stop</code> anytime to cancel an ongoing task.\n\n"
        "💡 <b>Tip:</b> Save this bot for quick access and seamless downloads!\n\n"
        "🚀 <b>Let's Get Started!</b>",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("📞 Contact Owner", url="https://t.me/aryan_patel_99")]]
        ),
        parse_mode=ParseMode.HTML
    )

@bot.on_message(filters.command("restart"))
async def restart_handler(_, m):
    if not is_authorized(m.chat.id):
        await m.reply_text("🚫 This bot is restricted to authorized chats only.\n\nPlease contact the owner to request access.")    
        return
    
    await m.reply_text("**I'm Restarted**🚦", True)
    os.execl(sys.executable, sys.executable, *sys.argv)


@bot.on_message(filters.command("stop"))
async def restart_handler(_, m):
    if not is_authorized(m.chat.id):
        await m.reply_text("🚫 This bot is restricted to authorized chats only.\n\nPlease contact the owner to request access.")
        return

    await m.reply_text("**🛑 Process Stopped** 🚦", True)
    os.execl(sys.executable, sys.executable, *sys.argv)


@bot.on_message(filters.command(["upload"]))
async def upload(bot: Client, m: Message):
    if not is_authorized(m.chat.id):
        await m.reply_text("🚫 This bot is restricted to authorized chats only.\n\nPlease contact the owner to request access.")
        return

    editable = await m.reply_text('📥 **Please send the .TXT file to begin the process.** ⚡')

    input: Message = await bot.listen(editable.chat.id)
    x = await input.download()
    await input.delete(True)

    path = f"./downloads/{m.chat.id}"

    try:
        with open(x, "r") as f:
            content = f.read()
        content = content.split("\n")
        links = []
        for i in content:
            links.append(i.split("://", 1))
        os.remove(x)
    except:
        await m.reply_text("❌ **Invalid file input.** Please ensure it's a valid .TXT file.")
        os.remove(x)
        return



    await editable.edit(f"🔗 **Found {len(links)} links in the file!**\n\n📝 Please specify from where you want to download (e.g., 1 for first link, 2 for second, etc.)")
    input0: Message = await bot.listen(editable.chat.id)
    raw_text = input0.text
    await input0.delete(True)

    await editable.edit("⚙ **Select desired video quality:**\n(144, 240, 360, 480, 720, 1080)")
    input2: Message = await bot.listen(editable.chat.id)
    raw_text2 = input2.text
    await input2.delete(True)
    
    try:
        if raw_text2 == "144":
            res = "256x144"
        elif raw_text2 == "240":
            res = "426x240"
        elif raw_text2 == "360":
            res = "640x360"
        elif raw_text2 == "480":
            res = "854x480"
        elif raw_text2 == "720":
            res = "1280x720"
        elif raw_text2 == "1080":
            res = "1920x1080" 
        else: 
            res = "UN"
    except Exception:
        res = "UN"

    await editable.edit("💬 **Enter a caption for your video (optional):**")
    input3: Message = await bot.listen(editable.chat.id)
    raw_text3 = input3.text
    await input3.delete(True)

    highlighter = f" "
    if raw_text3 == 'Robin':
        MR = highlighter 
    else:
        MR = raw_text3

    await editable.edit("📷 **Send a Thumbnail URL, type 'd' for default, or 'no' if you don't want a thumbnail:**")
    input6 = await bot.listen(editable.chat.id)
    raw_text6 = input6.text.strip()
    await input6.delete(True)
    await editable.delete()

    thumb = raw_text6.lower()

    if thumb.startswith("http://") or thumb.startswith("https://"):
        getstatusoutput(f"wget '{thumb}' -O 'thumb.jpg'")
        thumb = "thumb.jpg"
    elif thumb == "d":
        thumb = "default"
    else:
        thumb = "no"


    if len(links) == 1:
        count = 1
    else:
        count = int(raw_text)

    try:
        for i in range(count - 1, len(links)):

            V = links[i][1].replace("file/d/", "uc?export=download&id=").replace("www.youtube-nocookie.com/embed", "youtu.be").replace("?modestbranding=1", "").replace("/view?usp=sharing", "")
            url = "https://" + V

            if "visionias" in url:
                async with ClientSession() as session:
                    async with session.get(url, headers={'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'Accept-Language': 'en-US,en;q=0.9', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive', 'Pragma': 'no-cache', 'Referer': 'http://www.visionias.in/', 'Sec-Fetch-Dest': 'iframe', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-Site': 'cross-site', 'Upgrade-Insecure-Requests': '1', 'User-Agent': 'Mozilla/5.0 (Linux; Android 12; RMX2121) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36', 'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"', 'sec-ch-ua-mobile': '?1', 'sec-ch-ua-platform': '"Android"',}) as resp:
                        text = await resp.text()
                        url = re.search(r"(https://.*?playlist.m3u8.*?)\"", text).group(1)

            elif 'classplusapp' in url:
                logging.info("ClassPlus video URL detected.")
                content_id = url.split('contentId=')[1].split('&')[0] if 'contentId=' in url else None
                
                try:
                    processed_url = process_url(content_id)
                    if processed_url:
                        logging.info(f"Final processed URL: {processed_url}")
                        # Use the processed URL for further processing
                        url = processed_url  # Assign the processed URL back to the original `url` variable
                    else:
                        logging.error("Failed to get a processed URL.")
                        await m.reply_text("**Failed to process the video URL.**")
                except Exception as e:
                    logging.error(f"Error calling key.py: {e}")
                    await m.reply_text(f"**Error occurred while processing the URL.**\n{str(e)}")

            elif '/master.mpd' in url:
                match = re.search(r'/([0-9a-fA-F\-]{36})/master\.mpd', url)
                if match:
                    video_id = match.group(1)
                    print("Video ID:", video_id)
                else:
                    print("Video ID not found.")

                auth=AUTH
                link = url
                uuid = UUID
                # Generate the output URL
                url = f"https://pw-links-api.onrender.com/process?url={link}&&quality={raw_text2}&token={auth}"

            name1 = links[i][0].replace("\t", "").replace(":", "").replace("/", "").replace("+", "").replace("#", "").replace("|", "").replace("@", "").replace("*", "").replace(".", "").replace("https", "").replace("http", "").replace("'", "").replace('"', "").replace("~", "").replace("(", "").replace(")", "").replace("{", "").replace("}", "").replace("[", "").replace("]", "").replace("<", "").replace(">", "").replace("!", "").replace("$", "").replace("&", "").replace(",", "").replace(";", "").replace("=", "").replace("?", "").replace("^", "").replace("`", "").replace("\\", "").strip()
            name = f'{str(count).zfill(3)}) {name1[:60]}'

            if "youtu" in url:
                ytf = f"b[height<={raw_text2}][ext=mp4]/bv[height<={raw_text2}][ext=mp4]+ba[ext=m4a]/b[ext=mp4]"
            else:
                ytf = f"b[height<={raw_text2}]/bv[height<={raw_text2}]+ba/b/bv+ba"

            if "cdn.classplus" in url:
                cmd = f'N_m3u8DL-RE "{url}" --save-name "{name}" --thread-count 30  -sv for=best -sa 1 --key-text-file keys.txt -M format=mp4'
            elif "jw-prod" in url:
                cmd = f'aria2c -x 16 -j 32 -s 32 --file-allocation none -o "{name}.mp4" "{url}"'
            elif "mpd" in url and "/drm/" in url:
                cmd = f'curl -o {video_id}.mpd "{url}" && curl -o keys.txt https://pw-links-api.onrender.com/keys/{video_id} && N_m3u8DL-RE {video_id}.mpd --save-name "{name}" --thread-count 80 -sv res={res}:for=best -sa 1 --key-text-file keys.txt -M format=mp4  && rm -rf "{name}".m4a {video_id}.mpd'
            elif "mpd" in url and not "/drm/" in url:
                cmd = f'N_m3u8DL-RE "{url}" --save-name "{name}" --thread-count 80'
            else:
                cmd = f'yt-dlp -f "{ytf}" "{url}" -o "{name}.mp4"'


            try:  
                cc = f"🎞**𝐕𝐈𝐃_𝐈𝐃 »** `{str(count).zfill(3)}` \n\n**{MR}** \n\n💿 **➭ 𝐓𝐢𝐭𝐥𝐞 »** `{𝗻𝗮𝗺𝗲𝟭}.mkv` \n\n🔍 **𝐄𝐱𝐭𝐫𝐚𝐜𝐭𝐞𝐝 𝐁𝐲 »** [𝙰𝚁𝚈𝙰𝙽 🦅 𝙿𝙰𝚃𝙴𝙻](t.me/aryan_patel_99) \n\n━━━✦ 🔥 𝕬𝖗𝖞𝖆𝖓 𝕻𝖆𝖙𝖊𝖑 🔥 ✦━━━"


                cc1 = f"📁 **𝐏𝐃𝐅_𝐈𝐃 »** `{str(count).zfill(3)}` \n\n💿 **➭ 𝐓𝐢𝐭𝐥𝐞 »** `{𝗻𝗮𝗺𝗲𝟭}.mkv`"

                if "drive" in url:
                    try:
                        ka = await helper.download(url, name)
                        copy = await bot.send_document(chat_id=m.chat.id, document=ka, caption=cc1)
                        count += 1
                        os.remove(ka)
                        time.sleep(1)
                    except FloodWait as e:
                        await m.reply_text(str(e))
                        time.sleep(e.x)
                        continue

                elif ".pdf" in url:
                    try:
                        cmd = f'wget -O "{name}.pdf" "{url}"'
                        download_cmd = f"{cmd} --timeout=10 --tries=5 --retry-connrefused --waitretry=2"
                        os.system(download_cmd)
                        copy = await bot.send_document(chat_id=m.chat.id, document=f'{name}.pdf', caption=cc1)
                        count += 1
                        os.remove(f'{name}.pdf')
                    except FloodWait as e:
                        await m.reply_text(str(e))
                        time.sleep(e.x)
                        continue
                else:
                    Show = f"**⥥ 🚀 𝙎𝙏𝘼𝙍𝙏𝙄𝙉𝙂 𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿 ⬇⬇... »**\n\n**🔄 𝙏𝘼𝙎𝙆_𝙄𝘿 »** `{str(count).zfill(3)}`\n\n**📝 𝙉𝘼𝙈𝙀 »** `{name}`\n\n**🎞 𝙌𝙐𝘼𝙇𝙞𝙏𝙔 »** `{raw_text2}`\n\n**🔗 𝗨𝗥𝗟 »** `{url}`"
                    prog = await m.reply_text(Show)
                    res_file = await helper.download_video(url, cmd, name)
                    filename = res_file
                    await prog.delete(True)
                    name, video_url = links[i]
                    await helper.send_vid(bot, m, cc, filename, thumb, name, prog)
                    count += 1
                    time.sleep(1)

            except Exception as e:
                await m.reply_text(
                    f"❌ **Error during download:**\n{str(e)}\n**Name** » {name}\n**Link** » `{url}`"
                )
                continue

    except Exception as e:
        await m.reply_text(f"⚠ **An error occurred:**\n{e}")
    await m.reply_text("✅ **Download Complete!** Enjoy your file, Boss 😎")

bot.run()
