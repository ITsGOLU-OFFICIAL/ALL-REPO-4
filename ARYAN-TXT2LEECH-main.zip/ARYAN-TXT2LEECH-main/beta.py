#import asyncio
#import uvloop
#asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())

import os
import re
import sys
import json
import time

import requests
import subprocess
import uvloop
import core as helper
from utils import progress_bar
from vars import API_ID, API_HASH, BOT_TOKEN, AUTHORIZED_CHATS, AUTH
from aiohttp import ClientSession
from pyromod import listen
from subprocess import getstatusoutput

from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup
from pyrogram.errors import FloodWait

from pyrogram.errors.exceptions.bad_request_400 import StickerEmojiInvalid
import hmac
import hashlib
from pyrogram.enums import ParseMode
import xml.etree.ElementTree as ET
import logging
from aiohttp import web

bot = Client(
    "bot",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN
)

# Signature generation function
def generate_signature(data, secret_key):
    return hmac.new(secret_key.encode(), data.encode(), hashlib.sha256).hexdigest()

# Check if chat is authorized
def is_authorized(chat_id):
    return str(chat_id) in AUTHORIZED_CHATS

def sanitize_name(name):
    return name.strip().replace("\t", "").replace(":", "").replace("/", "").replace("+", "").replace("#", "").replace("|", "").replace("@", "").replace("*", "").replace(".", "").replace(":https", "").replace(":http", "").replace("'", "").replace('"', "").replace("~", "").replace("(", "").replace(")", "").replace("{", "").replace("}", "").replace("[", "").replace("]", "").replace("<", "").replace(">", "").replace("!", "").replace("$", "").replace("&", "").replace(",", "").replace(";", "").replace("=", "").replace("?", "").replace("^", "").replace("`", "").replace("\\", "").replace("http", "").replace("https", "")


    

@bot.on_message(filters.command(["start"]))
async def start(bot: Client, m: Message):
    if not is_authorized(m.chat.id):
        await m.reply_text(
            "🚫 <b>Access Denied!</b>\n\n"
            "This bot is <b>restricted</b> to authorized users only. 🔒\n\n"
            "💡 <b>What is this bot?</b>\n"
            "This is a <b>TXT2Leech bot</b> that helps you extract and download links from "
            "<code>.TXT</code> files 📄 and supports various platforms like <b>PW, Classplus, and more</b>! 🚀\n\n"
            "If you need access to our services, please contact the bot owner. 📩\n\n"
            "📞 <b>Request Access Below:</b>",
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("📞 Contact Owner", url="https://t.me/aryan_patel_99")]]
            ),
            parse_mode=ParseMode.HTML
        )
        return

    await m.reply_text(
        f"👋 <b>Welcome, {m.from_user.mention}!</b>\n\n"
        "🚀 <b>I'm your personal assistant bot, designed to make your life easier!</b>\n"
        "I help you extract and process download links from <code>.TXT</code> files 📄 "
        "and then upload the processed files directly to Telegram! 📤\n\n"
        "<b>🎯 How to Get Started?</b>\n"
        "1 Send <code>/upload</code> to start processing your file.\n"
        "2 Follow the prompts to complete the process.\n"
        "3 Use <code>/stop</code> anytime to cancel an ongoing task.\n\n"
        "💡 <b>Tip:</b> Save this bot for quick access and seamless downloads!\n\n"
        "🚀 <b>Let's Get Started!</b>",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("📞 Contact Owner", url="https://t.me/aryan_patel_99")]]
        ),
        parse_mode=ParseMode.HTML
    )

@bot.on_message(filters.command("restart"))
async def restart_handler(_, m):
    if not is_authorized(m.chat.id):
        await m.reply_text("🚫 This bot is restricted to authorized chats only.\n\nPlease contact the owner to request access.")    
        return
    
    await m.reply_text("**I'm Restarted**🚦", True)
    os.execl(sys.executable, sys.executable, *sys.argv)


@bot.on_message(filters.command("stop"))
async def restart_handler(_, m):
    if not is_authorized(m.chat.id):
        await m.reply_text("🚫 This bot is restricted to authorized chats only.\n\nPlease contact the owner to request access.")
        return

    await m.reply_text("**🛑 Process Stopped** 🚦", True)
    os.execl(sys.executable, sys.executable, *sys.argv)


from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery

# Temporary storage for user's content type selection
user_selected_type = {}


# /upload command handler
@bot.on_message(filters.command(["upload"]))
async def upload(bot: Client, m: Message):
    if not is_authorized(m.chat.id):
        await m.reply_text("🚫 This bot is restricted to authorized chats only.\n\nPlease contact the owner to request access.")
        return

    # Ask user to select content type
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("📹 Video", callback_data="type_video"),
         InlineKeyboardButton("📘 DPP Notes", callback_data="type_dpp")],
        [InlineKeyboardButton("📝 Notes", callback_data="type_notes"),
         InlineKeyboardButton("📀 DPP Video", callback_data="type_dppvideo")],
        [InlineKeyboardButton("✅ All", callback_data="type_all")]
    ])
    await m.reply_text("📂 **Select content type to process:**", reply_markup=keyboard)

# Handle button press
@bot.on_callback_query(filters.regex(r"^type_"))
async def type_selected(bot: Client, cq: CallbackQuery):
    selected_type = cq.data.split("_")[1]  # "video", "notes", "dpp", "dppvideo", "all"
    user_selected_type[cq.from_user.id] = selected_type
    await cq.message.edit(f"✅ **Selected content type:** `{selected_type.upper()}`\n\n📥 Now send the `.JSON` file to begin processing.")
    await cq.answer()

# Handle uploaded JSON
@bot.on_message(filters.document & filters.private)
async def handle_json_upload(bot: Client, m: Message):
    if not is_authorized(m.chat.id):
        await m.reply_text("🚫 This bot is restricted to authorized chats only.")
        return

    user_id = m.from_user.id
    if user_id not in user_selected_type:
        await m.reply_text("⚠️ Please use /upload and select content type first.")
        return

    selected_type = user_selected_type.pop(user_id)
    x = await m.download()
    await m.delete(True)
    links = []

    try:
        with open(x, "r", encoding="utf-8") as f:
            data = json.load(f)
        os.remove(x)

        for batch_name, subjects in data.items():
            for subject_name, topics in subjects.items():
                for topic_name, content in topics.items():
                    if not isinstance(content, dict):
                        continue

                    # 1. Regular Videos
                    if selected_type in ("video", "all"):
                        videos = content.get("videos", [])
                        if isinstance(videos, list):
                            for entry in videos:
                                if ':' not in entry:
                                    continue
                                try:
                                    title, url = entry.rsplit(":", 1)
                                    name = sanitize_name(title.strip())
                                    links.append([
                                        batch_name, subject_name, topic_name,
                                        "Video", name, url.strip()
                                    ])
                                except Exception as e:
                                    print(f"⚠️ Skipping malformed video entry: {entry}\nError: {e}")

                    # 2. DPP Videos
                    if selected_type in ("dppvideo", "all"):
                        dpp_videos = content.get("DppVideos", [])
                        if isinstance(dpp_videos, list):
                            for entry in dpp_videos:
                                if ':' not in entry:
                                    continue
                                try:
                                    title, url = entry.rsplit(":", 1)
                                    name = sanitize_name(title.strip())
                                    links.append([
                                        batch_name, subject_name, topic_name,
                                        "DPP Video", name, url.strip()
                                    ])
                                except Exception as e:
                                    print(f"⚠️ Skipping malformed DPP video entry: {entry}\nError: {e}")

                    # 3. DPP Notes
                    if selected_type in ("dpp", "all"):
                        dpps = content.get("DppNotes", [])
                        if isinstance(dpps, list):
                            for entry in dpps:
                                if ':' not in entry:
                                    continue
                                try:
                                    title, url = entry.rsplit(":", 1)
                                    name = sanitize_name(title.strip())
                                    links.append([
                                        batch_name, subject_name, topic_name,
                                        "DPP Notes", name, url.strip()
                                    ])
                                except Exception as e:
                                    print(f"⚠️ Skipping malformed DPP note entry: {entry}\nError: {e}")

                    # 4. Notes
                    if selected_type in ("notes", "all"):
                        notes = content.get("notes", [])
                        if isinstance(notes, list):
                            for entry in notes:
                                if ':' not in entry:
                                    continue
                                try:
                                    title, url = entry.rsplit(":", 1)
                                    name = sanitize_name(title.strip())
                                    links.append([
                                        batch_name, subject_name, topic_name,
                                        "Notes", name, url.strip()
                                    ])
                                except Exception as e:
                                    print(f"⚠️ Skipping malformed note entry: {entry}\nError: {e}")

    except Exception as e:
        await m.reply_text(f"❌ **Invalid JSON file.**\n\nError: `{e}`")
        os.remove(x)






    # Send a new message instead of editing the original document message
    msg = await m.reply_text(
        f"🔗 **Found {len(links)} links in the file!**\n\n📝 Please specify from where you want to download (e.g., 1 for first link, 2 for second, etc.)"
    )
    input0: Message = await bot.listen(m.chat.id)
    raw_text = input0.text
    await input0.delete(True)

    await msg.edit("⚙ **Select desired video quality:**\n(144, 240, 360, 480, 720, 1080)")
    input2: Message = await bot.listen(m.chat.id)
    raw_text2 = input2.text
    await input2.delete(True)

    # resolution logic
    res = {
        "144": "256x144",
        "240": "426x240",
        "360": "640x360",
        "480": "854x480",
        "720": "1280x720",
        "1080": "1920x1080"
    }.get(raw_text2, "UN")

    await msg.edit("💬 **Enter a caption for your video (optional):**")
    input3: Message = await bot.listen(m.chat.id)
    raw_text3 = input3.text
    await input3.delete(True)

    MR = " " if raw_text3 == "Robin" else raw_text3

    await msg.edit("📷 **Send a Thumbnail URL, type 'd' for default, or 'no' if you don't want a thumbnail:**")
    input6: Message = await bot.listen(m.chat.id)
    raw_text6 = input6.text.strip()
    await input6.delete(True)

    await msg.delete()  # clean the prompt chain

    thumb = raw_text6.lower()
    if thumb.startswith("http://") or thumb.startswith("https://"):
        getstatusoutput(f"wget '{thumb}' -O 'thumb.jpg'")
        thumb = "thumb.jpg"
    elif thumb == "d":
        thumb = "default"
    else:
        thumb = "no"

    count = 1 if len(links) == 1 else int(raw_text)


    try:
        for i in range(count - 1, len(links)):
            print(links[i][5])
            V = links[i][5].replace("file/d/", "uc?export=download&id=").replace("www.youtube-nocookie.com/embed", "youtu.be").replace("?modestbranding=1", "").replace("/view?usp=sharing", "")
            url = "https:" + V

            if "visionias" in url:
                async with ClientSession() as session:
                    async with session.get(url, headers={'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'Accept-Language': 'en-US,en;q=0.9', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive', 'Pragma': 'no-cache', 'Referer': 'http://www.visionias.in/', 'Sec-Fetch-Dest': 'iframe', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-Site': 'cross-site', 'Upgrade-Insecure-Requests': '1', 'User-Agent': 'Mozilla/5.0 (Linux; Android 12; RMX2121) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36', 'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"', 'sec-ch-ua-mobile': '?1', 'sec-ch-ua-platform': '"Android"',}) as resp:
                        text = await resp.text()
                        url = re.search(r"(https://.*?playlist.m3u8.*?)\"", text).group(1)

            elif 'classplusapp' in url:
                logging.info("ClassPlus video URL detected.")
                
                try:
                    # Directly pass the URL to key.py for processing
                    result = subprocess.run(
                        ['python3', 'key.py', url],  # Passing the URL directly to key.py
                        capture_output=True, text=True
                    )
                    processed_url = result.stdout.strip()

                    if processed_url:
                        logging.info(f"Final processed URL: {processed_url}")
                        # Use the processed URL for further processing
                        url = processed_url  # Assign the processed URL back to the original `url` variable
                    else:
                        logging.error("Failed to get a processed URL.")
                        await m.reply_text("**Failed to process the video URL.**")
                except Exception as e:
                    logging.error(f"Error calling key.py: {e}")
                    await m.reply_text(f"**Error occurred while processing the URL.**\n{str(e)}")

            elif '/master.mpd' in url:
                match = re.search(r'/([0-9a-fA-F\-]{36})/master\.mpd', url)
                if match:
                    video_id = match.group(1)
                    print("Video ID:", video_id)
                else:
                    print("Video ID not found.")

                auth=AUTH
                link = url
                uuid = UUID
                # Generate the output URL
                url = f"https://pw-links-api.onrender.com/process?url={link}&quality={raw_text2}&token={auth}"

            elif 'jarvis' in url:
                link = url
                url =f"https://pw-links-api.onrender.com/jarvis?url={link}"


            name1 = links[i][4]
            name = f'{str(count).zfill(3)}) {name1[:60]}'

            batch_name = links[i][0].replace("\t", "").replace(":", "").replace("/", "").replace("+", "").replace("#", "").replace("|", "").replace("@", "").replace("*", "").replace(".", "").replace(":https", "").replace(":http", "").replace("'", "").replace('"', "").replace("~", "").replace("(", "").replace(")", "").replace("{", "").replace("}", "").replace("[", "").replace("]", "").replace("<", "").replace(">", "").replace("!", "").replace("$", "").replace("&", "").replace(",", "").replace(";", "").replace("=", "").replace("?", "").replace("^", "").replace("`", "").replace("\\", "").strip()


            subject_name = links[i][1].replace("\t", "").replace(":", "").replace("/", "").replace("+", "").replace("#", "").replace("|", "").replace("@", "").replace("*", "").replace(".", "").replace(":https", "").replace(":http", "").replace("'", "").replace('"', "").replace("~", "").replace("(", "").replace(")", "").replace("{", "").replace("}", "").replace("[", "").replace("]", "").replace("<", "").replace(">", "").replace("!", "").replace("$", "").replace("&", "").replace(",", "").replace(";", "").replace("=", "").replace("?", "").replace("^", "").replace("`", "").replace("\\", "").strip()


            topic_name = links[i][2].replace("\t", "").replace(":", "").replace("/", "").replace("+", "").replace("#", "").replace("|", "").replace("@", "").replace("*", "").replace(".", "").replace(":https", "").replace(":http", "").replace("'", "").replace('"', "").replace("~", "").replace("(", "").replace(")", "").replace("{", "").replace("}", "").replace("[", "").replace("]", "").replace("<", "").replace(">", "").replace("!", "").replace("$", "").replace("&", "").replace(",", "").replace(";", "").replace("=", "").replace("?", "").replace("^", "").replace("`", "").replace("\\", "").strip()


            content = links[i][3]

            if "youtu" in url:
                ytf = f"b[height<={raw_text2}][ext=mp4]/bv[height<={raw_text2}][ext=mp4]+ba[ext=m4a]/b[ext=mp4]"
            else:
                ytf = f"b[height<={raw_text2}]/bv[height<={raw_text2}]+ba/b/bv+ba"

            if "cdn.classplus" in url:
                cmd = f'N_m3u8DL-RE "{url}" --save-name "{name}"  -sv res={res}:for=best -sa 1 --key-text-file keys.txt'
            elif "jw-prod" in url:
                cmd = f'aria2c -x 16 -j 32 -s 32 --file-allocation none -o "{name}.mp4" "{url}"'
            elif "mpd" in url and "/drm/" in url:
                cmd = f'curl -o {video_id}.mpd "{url}" && curl -o keys.txt https://pw-links-api.onrender.com/keys/{video_id} && N_m3u8DL-RE {video_id}.mpd --save-name "{name}" --thread-count 80 -sv res={res}:for=best -sa 1 --key-text-file keys.txt -M format=mp4  && rm -rf "{name}".m4a {video_id}.mpd'
            elif "mpd" in url  and "/drm/" not in url:
                cmd = f'N_m3u8DL-RE "{url}" --save-name "{name}" --thread-count 80'
            else:
                cmd = f'yt-dlp -f "{ytf}" "{url}" -o "{name}.mp4"'


            try:  
                cc = f"🎞**𝐕𝐈𝐃_𝐈𝐃 »** `{str(count).zfill(3)}` \n\n📦 **𝐁𝐚𝐭𝐜𝐡**: `{batch_name}`\n📚 **𝐒𝐮𝐛𝐣𝐞𝐜𝐭**: `{subject_name}`\n🗂️ **𝐓𝐨𝐩𝐢𝐜**: `{topic_name}`\n\n💿 **𝐓𝐢𝐭𝐥𝐞**: `{name1}.mkv`"


                cc1 = f"📁 **𝐏𝐃𝐅_𝐈𝐃 »** `{str(count).zfill(3)}` \n\n📦 **𝐁𝐚𝐭𝐜𝐡**: `{batch_name}`\n📚 **𝐒𝐮𝐛𝐣𝐞𝐜𝐭**: `{subject_name}`\n🗂️ **𝐓𝐨𝐩𝐢𝐜**: `{topic_name}` `{content}`\n\n💿 **𝐓𝐢𝐭𝐥𝐞**: `{name1}.pdf`"

                if "drive" in url:
                    try:
                        ka = await helper.download(url, name)
                        copy = await bot.send_document(chat_id=m.chat.id, document=ka, caption=cc1)
                        count += 1
                        os.remove(ka)
                        time.sleep(1)
                    except FloodWait as e:
                        await m.reply_text(str(e))
                        time.sleep(e.x)
                        continue

                elif ".pdf" in url:
                    try:
                        cmd = f'wget -O "{name}.pdf" "{url}"'
                        download_cmd = f"{cmd} --timeout=10 --tries=5 --retry-connrefused --waitretry=2"
                        os.system(download_cmd)
                        copy = await bot.send_document(chat_id=m.chat.id, document=f'{name}.pdf', caption=cc1)
                        count += 1
                        os.remove(f'{name}.pdf')
                    except FloodWait as e:
                        await m.reply_text(str(e))
                        time.sleep(e.x)
                        continue
                else:
                    Show = f"**⥥ 🚀 𝙎𝙏𝘼𝙍𝙏𝙄𝙉𝙂 𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿 ⬇⬇... »**\n\n**🔄 𝙏𝘼𝙎𝙆_𝙄𝘿 »** `{str(count).zfill(3)}`\n\n**📝 𝙉𝘼𝙈𝙀 »** `{name}`\n\n**🎞 𝙌𝙐𝘼𝙇𝙞𝙏𝙔 »** `{raw_text2}`\n\n**🔗 𝗨𝗥𝗟 »** `{url}`"
                    prog = await m.reply_text(Show)
                    res_file = await helper.download_video(url, cmd, name)
                    filename = res_file
                    await prog.delete(True)
                    name = links[i][4]
                    await helper.send_vid(bot, m, cc, filename, thumb, name, prog)
                    count += 1
                    time.sleep(120)

            except Exception as e:
                await m.reply_text(
                    f"❌ **Error during download:**\n{str(e)}\n**Name** » {name}\n**Link** » `{url}`"
                )
                continue

    except Exception as e:
        await m.reply_text(f"⚠ **An error occurred:**\n{e}")
    await m.reply_text("✅ **Download Complete!** Enjoy your file, Boss 😎")

bot.run()
