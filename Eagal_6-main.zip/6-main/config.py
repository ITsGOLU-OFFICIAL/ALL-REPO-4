import os
from os import getenv



# ------------------------------------------------
API_ID = int(os.environ.get("API_ID", ""))
# ------------------------------------------------
API_HASH = os.environ.get("API_HASH","")
# ------------------------------------------------
BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
# ------------------------------------------------
BOT_USERNAME = os.environ.get("BOT_USERNAME", "")
BOT_TEXT = "🦅Golden Eagle🦅"
# ------------------------------------------------
OWNER_ID = int(os.environ.get("OWNER_ID", ""))
# ------------------------------------------------
# //LOG CHANNEL ID 
CHANNEL_ID = int(os.environ.get("CHANNEL_ID", ""))

# //FORCE_CHANNEL_ID
CHANNEL_ID2 = int(os.environ.get("CHANNEL_ID2", "")) 
# -----------------------------------------------
MONGO_URL = os.environ.get("MONGO_URL", "")
# -----------------------------------------------
PREMIUM_LOGS = int(os.environ.get("PREMIUM_LOGS", ""))
# -----------------------------------------------
join = '<a href="https://t.me/jgckco">✳️ Bᴀᴄᴋᴜᴘ</a>'
# -----------------------------------------------
UNSPLASH_ACCESS_KEY = ''
# -----------------------------------------------
UNSPLASH_QUERY = ''
# -----------------------------------------------
ADMIN_BOT_USERNAME = "" #without @

THUMB_URL = os.environ.get("THUMB_URL", "https://i.ibb.co/zTPJFct8/photo-2025-04-25-12-55-01-7497233558289776672.jpg")




# # Bot configuration
# API_ID = int(os.environ.get("API_ID", "22746239"))
# API_HASH = os.environ.get("API_HASH", "a98ec8cfd8572a3a7c936cf828fe6215")
# BOT_TOKEN = os.environ.get("BOT_TOKEN", "7547829346:AAGyfvOu47EciNhC7NUGSDEDFuBaetYYusw")
# BOT_USERNAME = os.environ.get("BOT_USERNAME", "MassRPBot")
# OWNER_ID = int(os.environ.get("OWNER_ID", "7463601722"))
# SUDO_USERS = list(map(int, getenv("SUDO_USERS", "7463601722").split()))
# CHANNEL_ID = int(os.environ.get("CHANNEL_ID", "-1002601604234"))
# MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://wadiro6523:08AwfhhKRdQaS1i6@cluster0.krzxuop.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
# PREMIUM_LOGS = int(os.environ.get("PREMIUM_LOGS", "-1002601604234"))
# THUMB_URL = os.environ.get("THUMB_URL", "https://i.fbcd.co/products/original/ug-circle-logo-design-2-e84695ca2ab9a697d2b2d7c928b0bf5f12bf18e076da241815e0372c8d617915.jpg")

