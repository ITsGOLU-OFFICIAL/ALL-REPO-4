python main.py    # Phir main.py run karega
