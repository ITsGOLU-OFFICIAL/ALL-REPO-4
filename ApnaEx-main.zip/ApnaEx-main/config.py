import os
from os import getenv


# ------------------------------------------------
API_ID = int(os.environ.get("API_ID", "15964777"))
# ------------------------------------------------
API_HASH = os.environ.get("API_HASH","ef448f85b780cdf26f8ffe390a5d8262")
# ------------------------------------------------
BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
# ------------------------------------------------
BOT_USERNAME = os.environ.get("BOT_USERNAME", "@@Downloaderapna10bot")
BOT_TEXT = "Downloader 10"
# ------------------------------------------------
OWNER_ID = int(os.environ.get("OWNER_ID", "944358553"))
# ------------------------------------------------
# //LOG CHANNEL ID 
CHANNEL_ID = int(os.environ.get("CHANNEL_ID", "-1002683859662"))

# //FORCE_CHANNEL_ID
CHANNEL_ID2 = int(os.environ.get("CHANNEL_ID2", "-1002471859014")) 
# ------------------------------------------------
MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://besib69802:YMOfgvnyjbRgW5qt@cluster0.yzzu2gn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
# -----------------------------------------------
PREMIUM_LOGS = int(os.environ.get("PREMIUM_LOGS", "-1002829170533"))
# -----------------------------------------------
join = '<a href="https://t.me/+MgPgCAPUOVU2Yjhl">✳️ JOIN BACKUP</a>'
# -----------------------------------------------
UNSPLASH_ACCESS_KEY = 'RabDRmuXXBobanmwwbvpP5LwoG4J8ox34y5Sstz-9jk'
# -----------------------------------------------
UNSPLASH_QUERY = 'animal baby'
# -----------------------------------------------
ADMIN_BOT_USERNAME = "UGxPRO" #without @

THUMB_URL = os.environ.get("THUMB_URL", "https://josephscollege.ac.in/wp-content/uploads/2022/04/1.jpg")




# # Bot configuration
# API_ID = int(os.environ.get("API_ID", "22746239"))
# API_HASH = os.environ.get("API_HASH", "a98ec8cfd8572a3a7c936cf828fe6215")
# BOT_TOKEN = os.environ.get("BOT_TOKEN", "7547829346:AAGyfvOu47EciNhC7NUGSDEDFuBaetYYusw")
# BOT_USERNAME = os.environ.get("BOT_USERNAME", "MassRPBot")
# OWNER_ID = int(os.environ.get("OWNER_ID", "7463601722"))
# SUDO_USERS = list(map(int, getenv("SUDO_USERS", "7463601722").split()))
# CHANNEL_ID = int(os.environ.get("CHANNEL_ID", "-1002601604234"))
# MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://wadiro6523:08AwfhhKRdQaS1i6@cluster0.krzxuop.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
# PREMIUM_LOGS = int(os.environ.get("PREMIUM_LOGS", "-1002601604234"))
# THUMB_URL = os.environ.get("THUMB_URL", "https://i.fbcd.co/products/original/ug-circle-logo-design-2-e84695ca2ab9a697d2b2d7c928b0bf5f12bf18e076da241815e0372c8d617915.jpg")

