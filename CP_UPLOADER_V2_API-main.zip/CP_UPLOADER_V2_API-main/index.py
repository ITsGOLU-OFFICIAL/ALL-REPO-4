# index.py - Complete Updated API
import os
import re
import uuid
import time
import requests
import imaplib
import email
from email.header import decode_header
import random
import logging
from flask import Flask, request, jsonify
from flask_cors import CORS
import json

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Environment variables
EMAIL_ADDRESS = os.getenv("EMAIL_ADDRESS", "")
EMAIL_APP_PASSWORD = os.getenv("EMAIL_APP_PASSWORD", "")
OWNER = os.getenv("OWNER", "Unknown Owner")

# Token cache
token_cache = {"tokens": [], "last_cleanup": time.time()}
token_count = 0

# Organization configurations
ORG_CONFIGS = [
    {"org_code": "ixgioj", "org_id": "735592", "org_name": "Classplus"},
    {"org_code": "zgoxm", "org_id": "896887", "org_name": "OrgA"},
    {"org_code": "wuhki", "org_id": "1681", "org_name": "OrgB"},
    {"org_code": "wfodo", "org_id": "7845", "org_name": "OrgC"},
    {"org_code": "rpsc", "org_id": "122707", "org_name": "OrgD"},
]

# --- FIXED: Removed extra spaces from URLs ---
API_BASE_URL = "https://api.classplusapp.com"

# Helper Functions
def generate_random_mobile():
    first_digit = random.choice(["6", "7", "8", "9"])
    mobile = first_digit
    for _ in range(9):
        mobile += str(random.randint(0, 9))
    return mobile

def generate_random_name():
    names = [
        "Anika", "Atharv", "Navya", "Myra", "Aarav", "Ishika",
        "Vihaan", "Aanya", "Kabir", "Prisha", "Advait", "Sia",
        "Arjun", "Ira", "Reyansh", "Anvi", "Krishna", "Aadhya",
        "Vivaan", "Diya", "Rudra", "Meera", "Ayaan", "Kiara"
    ]
    return random.choice(names)

def generate_gmail_alias(base_email, suffix):
    if not base_email or '@' not in base_email:
        return f"{base_email}+{suffix}@gmail.com"
    local_part, domain = base_email.split('@', 1)
    return f"{local_part}+{suffix}@{domain}"

def mask_email(email):
    if not email or '@' not in email:
        return email
    username, domain = email.split('@')
    masked_username = username[0] + '*' * (len(username) - 1) if len(username) > 1 else username
    domain_parts = domain.split('.')
    tld = domain_parts.pop()
    masked_domain_parts = [part[0] + '*' * (len(part) - 1) if len(part) > 1 else part for part in domain_parts]
    masked_domain = '.'.join(masked_domain_parts) + ('.' if domain_parts else '') + tld
    return masked_username + '@' + masked_domain

def decode_mime_words(s):
    if not s:
        return ""
    decoded = []
    for part, encoding in decode_header(s):
        if isinstance(part, bytes):
            try:
                decoded.append(part.decode(encoding or 'utf-8'))
            except UnicodeDecodeError:
                decoded.append(part.decode('latin-1'))
        else:
            decoded.append(str(part))
    return ''.join(decoded)

# --- FIXED: Function signature to use global EMAIL_ADDRESS/EMAIL_APP_PASSWORD ---
def fetch_otp_from_gmail(target_email):
    """Fetches OTP from Gmail."""
    # Use global credentials
    user_email = EMAIL_ADDRESS
    user_password = EMAIL_APP_PASSWORD
    if not user_email or not user_password:
        logger.error("[ERROR] Gmail credentials not configured.")
        return None
    try:
        imap = imaplib.IMAP4_SSL("imap.gmail.com")
        imap.login(user_email, user_password)
        imap.select("INBOX")
        five_minutes_ago = time.time() - 5 * 60
        search_criteria = f'(UNSEEN SINCE {time.strftime("%d-%b-%Y", time.gmtime(five_minutes_ago))})'
        status, messages = imap.search(None, search_criteria)
        if status != "OK" or not messages[0]:
            logger.info("[INFO] No unseen emails found matching criteria.")
            imap.close()
            imap.logout()
            return None
        email_ids = messages[0].split()
        otp_found = None
        for email_id in reversed(email_ids): # Check newest first
            status, msg_data = imap.fetch(email_id, "(RFC822)")
            if status != "OK":
                continue
            raw_email = msg_data[0][1]
            email_message = email.message_from_bytes(raw_email)
            from_header = decode_mime_words(email_message.get("From", ""))
            to_header = decode_mime_words(email_message.get("To", ""))
            is_from_classplus = "info@ce.classplus.co" in from_header
            is_target_email = target_email in to_header
            if is_from_classplus and is_target_email:
                body = ""
                if email_message.is_multipart():
                    for part in email_message.walk():
                        content_type = part.get_content_type()
                        if content_type == "text/plain":
                            try:
                                body = part.get_payload(decode=True).decode('utf-8', errors='ignore')
                                break
                            except Exception as e:
                                logger.debug(f"[DEBUG] Error decoding part: {e}")
                else:
                    try:
                        body = email_message.get_payload(decode=True).decode('utf-8', errors='ignore')
                    except Exception as e:
                         logger.debug(f"[DEBUG] Error decoding email body: {e}")
                otp_matches = re.findall(r'\b\d{4}\b', body)
                if otp_matches:
                    otp_found = otp_matches[-1]
                    logger.info(f"[INFO] OTP extracted from email body: {otp_found}")
                    break
        imap.close()
        imap.logout()
        return otp_found
    except Exception as e:
        logger.error(f"[ERROR] IMAP error: {e}")
        return None

# --- FIXED: Removed extra space from API endpoint URL ---
def send_otp_email(email_address, org_code, org_id, org_name="Classplus"):
    """Sends OTP email via Classplus API."""
    try:
        device_id = str(uuid.uuid4()).replace('-', '')
        headers = {
            "Accept": "application/json, text/plain, */*",
            "region": "IN",
            "Content-Type": "application/json;charset=utf-8",
            "Api-Version": "51",
            "device-id": device_id,
            "User-Agent": "Mozilla/5.0"
        }
        otp_payload = {
            'countryExt': '91',
            'orgCode': org_code,
            'viaEmail': '1',
            'email': email_address,
            'orgId': org_id,
            'otpCount': 0
        }
        logger.info(f"[send_otp_email] Sending OTP to {email_address}")
        response = requests.post(f"{API_BASE_URL}/v2/otp/generate", json=otp_payload, headers=headers, timeout=20)
        logger.info(f"[send_otp_email] Status: {response.status_code}, Response: {response.text[:200]}")
        if response.status_code == 200:
            data = response.json()
            if "data" in data and "sessionId" in data["data"]:
                return {
                    "success": True,
                    "session_id": data['data']['sessionId'],
                    "org_id": org_id,
                    "org_name": org_name,
                    "org_code": org_code,
                    "device_id": device_id
                }
        try:
            error_data = response.json()
            error_msg = error_data.get('message', response.text)
        except:
            error_msg = response.text
        return {"success": False, "error": f"OTP send failed: {error_msg}"}
    except Exception as e:
        return {"success": False, "error": f"OTP send error: {str(e)}"}

# --- FIXED: Removed extra spaces from API endpoint URLs ---
def verify_otp_email(email_address, otp, session_id, org_id, device_id, org_code=""):
    """Verifies OTP and gets token."""
    try:
        device_id_str = device_id or str(uuid.uuid4()).replace('-', '')
        headers = {
            "Accept": "application/json, text/plain, */*",
            "region": "IN",
            "Content-Type": "application/json;charset=utf-8",
            "Api-Version": "51",
            "device-id": device_id_str,
            "User-Agent": "Mozilla/5.0"
        }
        fingerprint_id = str(uuid.uuid4()).replace('-', '')
        verify_payload = {
            "otp": otp,
            "countryExt": "91",
            "sessionId": session_id,
            "orgId": org_id,
            "fingerprintId": fingerprint_id,
            "email": email_address
        }
        logger.info(f"[verify_otp_email] Verifying OTP for {email_address}")
        response = requests.post(f"{API_BASE_URL}/v2/users/verify", json=verify_payload, headers=headers, timeout=20)
        logger.info(f"[verify_otp_email] Verify Status: {response.status_code}, Response: {response.text[:500]}")
        if response.status_code == 200:
            data = response.json()
            if data.get('status') == 'success' and 'token' in data.get('data', {}):
                return {"success": True, "token": data['data']['token']}
        if response.status_code in [201, 400, 404, 409]:
            random_mobile = generate_random_mobile()
            chosen_name = generate_random_name()
            register_payload = {
                "contact": {
                    "email": email_address,
                    "countryExt": "91",
                    "mobile": random_mobile
                },
                "fingerprintId": fingerprint_id,
                "name": chosen_name,
                "orgId": org_id,
                "orgName": "Classplus",
                "orgCode": org_code or "",
                "otp": otp,
                "sessionId": session_id,
                "type": 1,
                "viaEmail": 1,
                "viaSms": 0
            }
            logger.info(f"[verify_otp_email] Registering new user {email_address}")
            reg_response = requests.post(f"{API_BASE_URL}/v2/users/register", json=register_payload, headers=headers, timeout=20)
            logger.info(f"[verify_otp_email] Register Status: {reg_response.status_code}, Response: {reg_response.text[:500]}")
            if reg_response.status_code == 200:
                 reg_data = reg_response.json()
                 if 'token' in reg_data.get('data', {}):
                     return {"success": True, "token": reg_data['data']['token']}
        try:
            customer_headers = {
                "Accept": "application/json, text/plain, */*",
                "Content-Type": "application/json;charset=utf-8",
            }
            customer_payload = {
                "email": email_address,
                "otp": otp,
                "countryCode": "+91",
                "userType": 0
            }
            logger.info(f"[verify_otp_email] Trying customer OTP verify for {email_address}")
            customer_resp = requests.post(f"{API_BASE_URL}/v2/customer/otp/verify", json=customer_payload, headers=customer_headers, timeout=20)
            logger.info(f"[verify_otp_email] Customer Verify Status: {customer_resp.status_code}, Response: {customer_resp.text[:500]}")
            if customer_resp.status_code == 200:
                cust_data = customer_resp.json()
                if 'accessToken' in cust_data.get('data', {}):
                    return {"success": True, "token": cust_data['data']['accessToken']}
        except Exception as cust_err:
            logger.info(f"[INFO] Customer OTP verification not applicable or failed: {cust_err}")
        try:
            error_data = response.json()
            error_msg = error_data.get('message', response.text)
        except:
            error_msg = response.text
        return {"success": False, "error": f"Verification failed: {error_msg}"}
    except Exception as e:
        return {"success": False, "error": f"Verification error: {str(e)}"}

def cleanup_expired_tokens():
    """Removes expired tokens from cache (older than 45 mins)."""
    current_time = time.time()
    if current_time - token_cache["last_cleanup"] > 300:
        token_cache["tokens"] = [
            token for token in token_cache["tokens"]
            if current_time - token["created_at"] < 2700
        ]
        token_cache["last_cleanup"] = current_time
        logger.info(f"[INFO] Token cache cleaned. Remaining: {len(token_cache['tokens'])}")

def get_cached_token():
    """Gets a valid cached token."""
    cleanup_expired_tokens()
    if token_cache["tokens"]:
        latest_token = token_cache["tokens"][-1]
        if time.time() - latest_token["created_at"] < 2400:
            logger.info("[INFO] Using cached token.")
            return latest_token["token"]
    logger.info("[INFO] No valid cached token found.")
    return None

def add_token_to_cache(token):
    """Adds a new token to the cache."""
    token_cache["tokens"].append({
        "token": token,
        "created_at": time.time()
    })
    logger.info("[INFO] New token added to cache.")

# --- FIXED: Function signature to use global EMAIL_ADDRESS/EMAIL_APP_PASSWORD ---
def generate_single_token():
    """Generates a single Classplus token."""
    global token_count
    # Use global EMAIL_ADDRESS
    base_email = EMAIL_ADDRESS
    user_email = EMAIL_ADDRESS
    user_password = EMAIL_APP_PASSWORD
    suffix = f"cpapi{int(time.time())}{random.choice('abcdefghijklmnopqrstuvwxyz0123456789')}{random.choice('abcdefghijklmnopqrstuvwxyz0123456789')}"
    email_address = generate_gmail_alias(base_email, suffix)
    if not base_email or '@' not in base_email:
         return {"success": False, "error": "EMAIL_ADDRESS not configured correctly."}
    choice = random.choice(ORG_CONFIGS)
    org_code, org_id, org_name = choice["org_code"], choice["org_id"], choice["org_name"]
    otp_result = send_otp_email(email_address, org_code, org_id, org_name)
    if not otp_result.get("success"):
        return {"success": False, "error": otp_result.get("error")}
    otp = None
    attempts = 0
    max_attempts = 15
    logger.info(f"[INFO] Waiting for OTP for {email_address}...")
    while attempts < max_attempts and not otp:
        time.sleep(5)
        try:
            # --- FIXED: Call fetch_otp_from_gmail correctly (no extra params needed now) ---
            otp = fetch_otp_from_gmail(email_address)
            if otp:
                logger.info(f"[INFO] Found OTP: {otp}")
        except Exception as e:
            logger.warning(f"[WARN] Error fetching OTP (attempt {attempts+1}): {e}")
        attempts += 1
    if not otp:
        return {"success": False, "error": "Failed to retrieve OTP from Gmail within time limit."}
    verify_result = verify_otp_email(
        email_address,
        otp,
        otp_result.get("session_id"),
        otp_result.get("org_id"),
        otp_result.get("device_id"),
        otp_result.get("org_code")
    )
    if verify_result.get("success"):
        token_count += 1
        masked_email = mask_email(email_address)
        logger.info(f"[SUCCESS] Token #{token_count} generated for {masked_email}")
        return {
            "success": True,
            "token": verify_result.get("token"),
            "email": masked_email,
            "otp_used": otp,
            "token_number": token_count
        }
    else:
        return {"success": False, "error": verify_result.get("error")}

def get_or_generate_token():
    """Gets a cached token or generates a new one."""
    token = get_cached_token()
    if token:
        return token
    logger.info("[INFO] Generating new token...")
    # --- FIXED: Call generate_single_token correctly (no params needed now) ---
    new_token_result = generate_single_token()
    if new_token_result.get("success"):
        add_token_to_cache(new_token_result["token"])
        return new_token_result["token"]
    else:
        logger.error(f"[ERROR] Failed to generate token: {new_token_result.get('error')}")
        return None

# --- FIXED: Removed extra spaces from API endpoint URL ---
def process_classplus_drm_url(original_url, access_token):
    """Processes a Classplus DRM URL using the provided token."""
    try:
        api_endpoint = f"{API_BASE_URL}/cams/uploader/video/jw-signed-url"
        adjusted_url = original_url
        if "cpvod.testbook.com" in original_url:
            adjusted_url = original_url.replace("https://cpvod.testbook.com/", "https://media-cdn.classplusapp.com/drm/")
        headers = {
            'host': 'api.classplusapp.com',
            'x-access-token': eyJjb3Vyc2VJZCI6IjQ1NjY4NyIsInR1dG9ySWQiOm51bGwsIm9yZ0lkIjo0ODA2MTksImNhdGVnb3J5SWQiOm51bGx9r,
            'accept-language': 'EN',
            'api-version': '18',
            'app-version': '1.4.73.2',
            'build-number': '35',
            'connection': 'Keep-Alive',
            'content-type': 'application/json',
            'device-details': 'Xiaomi_Redmi 7_SDK-32',
            'device-id': str(uuid.uuid4()).replace('-', '')[0:16],
            'region': 'IN',
            'user-agent': 'Mobile-Android',
            'webengage-luid': str(uuid.uuid4()),
            'accept-encoding': 'gzip'
        }
        params = {"url": adjusted_url}
        logger.info(f"[INFO] Calling Classplus API: {api_endpoint}")
        response = requests.get(api_endpoint, headers=headers, params=params, timeout=30)
        logger.info(f"[INFO] Classplus API Response Status: {response.status_code}")
        if response.status_code == 200:
            try:
                data = response.json()
                logger.debug(f"[DEBUG] Classplus API Response Body: {data}")
            except Exception as parse_err:
                 return {"success": False, "error": f"Failed to parse Classplus API JSON: {parse_err}. Raw: {response.text[:200]}"}
            signed_url = data.get('data', {}).get('url')
            if signed_url:
                 logger.info("[SUCCESS] Found signed URL in data.data.url")
                 return {"success": True, "url": signed_url}
            signed_url = data.get('url')
            if signed_url:
                 logger.info("[SUCCESS] Found signed URL in data.url")
                 return {"success": True, "url": signed_url}
            if data.get('success') == True and 'drmUrls' in data and data['drmUrls']:
                manifest_url = data['drmUrls'].get('manifestUrl')
                license_url = data['drmUrls'].get('licenseUrl')
                if manifest_url:
                    logger.info("[SUCCESS] Found manifest URL in drmUrls.manifestUrl")
                    response_data = {"success": True, "url": manifest_url}
                    if license_url:
                        response_data["license_url"] = license_url
                    return response_data
            if data.get('status') and data['status'] != 'ok':
                 error_message = data.get('message', 'Unknown explicit error from Classplus API')
                 return {"success": False, "error": f"Classplus API explicit error: {error_message}. Full response: {data}"}
            return {"success": False, "error": f"Signed/Manifest URL not found in expected locations. Response: {data}"}
        else:
            try:
                error_data = response.json()
                error_msg = error_data.get('message', response.text)
            except:
                error_msg = response.text
            return {
                "success": False,
                "error": f"Classplus API request failed (Status {response.status_code}): {error_msg[:500]}"
            }
    except requests.exceptions.Timeout:
        return {"success": False, "error": "Request to Classplus API timed out."}
    except requests.exceptions.RequestException as req_err:
         return {"success": False, "error": f"Network error calling Classplus API: {str(req_err)}"}
    except Exception as e:
        logger.error(f"[ERROR] Exception in process_classplus_drm_url: {e}", exc_info=True)
        return {"success": False, "error": f"Exception in processing DRM URL: {str(e)}"}

# API Endpoints
@app.route('/')
def home():
    """API information"""
    return jsonify({
        "message": "Classplus Token & Download API",
        "description": "API with automatic token generation and management",
        "owner": OWNER,
        "endpoints": {
            "POST /api/generate-token": "Generate a new Classplus token",
            "GET /api/get-token": "Get a valid token (cached or new)",
            "GET /api/token-cache": "View token cache information",
            "GET /api/token-health": "Check token system health",
            "GET /v1/api": "Process Classplus DRM URLs",
            "GET /api/process-non-drm": "Process non-DRM content",
            "GET /health": "General API health check",
            "GET /docs": "API documentation"
        },
        "note": "All token operations are automatic and cached for performance"
    })

@app.route('/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "timestamp": time.time(),
        "uptime": "API is running"
    })

# --- FIXED: Ensure EMAIL_ADDRESS and EMAIL_APP_PASSWORD are checked ---
@app.route('/api/generate-token', methods=['POST'])
def generate_token_endpoint():
    """Generate a new Classplus token"""
    try:
        # --- FIXED: Check global EMAIL_ADDRESS and EMAIL_APP_PASSWORD ---
        if not EMAIL_ADDRESS or '@' not in EMAIL_ADDRESS:
            return jsonify({
                "success": False,
                "error": "EMAIL_ADDRESS not configured in server environment variables"
            }), 400
            
        if not EMAIL_APP_PASSWORD:
            return jsonify({
                "success": False,
                "error": "EMAIL_APP_PASSWORD not configured in server environment variables"
            }), 400
        
        # --- FIXED: Call generate_single_token correctly (no params needed now) ---
        result = generate_single_token()
        
        if result["success"]:
            add_token_to_cache(result["token"])
            
            return jsonify({
                "success": True,
                "message": "Token generated successfully",
                "token": result["token"],
                "masked_email": result.get("email"),
                "expires_in": "40 minutes"
            })
        else:
            return jsonify({
                "success": False,
                "error": result.get("error", "Unknown error")
            }), 400
            
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"Token generation failed: {str(e)}"
        }), 500

# --- FIXED: Ensure EMAIL_ADDRESS and EMAIL_APP_PASSWORD are checked ---
@app.route('/api/get-token', methods=['GET'])
def get_token_endpoint():
    """Get a valid token (cached or generate new)"""
    try:
        token = get_cached_token()
        
        if token:
            return jsonify({
                "success": True,
                "token": token,
                "source": "cache",
                "message": "Using cached token"
            })
        
        # --- FIXED: Check global EMAIL_ADDRESS and EMAIL_APP_PASSWORD ---
        if not EMAIL_ADDRESS or '@' not in EMAIL_ADDRESS:
            return jsonify({
                "success": False,
                "error": "EMAIL_ADDRESS not configured in server environment variables"
            }), 400
            
        if not EMAIL_APP_PASSWORD:
            return jsonify({
                "success": False,
                "error": "EMAIL_APP_PASSWORD not configured in server environment variables"
            }), 400
        
        # --- FIXED: Call generate_single_token correctly (no params needed now) ---
        new_token_result = generate_single_token()
        
        if new_token_result.get("success"):
            add_token_to_cache(new_token_result["token"])
            
            return jsonify({
                "success": True,
                "token": new_token_result["token"],
                "source": "newly_generated",
                "masked_email": new_token_result.get("email"),
                "expires_in": "40 minutes"
            })
        else:
            return jsonify({
                "success": False,
                "error": new_token_result.get("error", "Unknown error")
            }), 400
            
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"Failed to get token: {str(e)}"
        }), 500

@app.route('/api/token-cache', methods=['GET'])
def token_cache_endpoint():
    """Get token cache information"""
    try:
        cleanup_expired_tokens()
        
        cache_info = {
            "total_tokens_generated": token_count,
            "cached_tokens": len(token_cache["tokens"]),
            "last_cleanup": token_cache["last_cleanup"],
            "cache_status": "active" if token_cache["tokens"] else "empty"
        }
        
        if token_cache["tokens"]:
            latest_token = token_cache["tokens"][-1]
            cache_info["latest_token_age"] = time.time() - latest_token["created_at"]
            cache_info["expires_in"] = max(0, 2400 - cache_info["latest_token_age"])
        
        return jsonify({
            "success": True,
            "cache_info": cache_info
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route('/api/token-health', methods=['GET'])
def token_health_endpoint():
    """Check token generation health"""
    try:
        # --- FIXED: Check global EMAIL_ADDRESS and EMAIL_APP_PASSWORD ---
        email_configured = bool(EMAIL_ADDRESS and '@' in EMAIL_ADDRESS)
        password_configured = bool(EMAIL_APP_PASSWORD)
        
        cleanup_expired_tokens()
        cache_status = {
            "total_tokens": token_count,
            "cached_count": len(token_cache["tokens"]),
            "last_cleanup": token_cache["last_cleanup"]
        }
        
        test_result = None
        if email_configured and password_configured:
            try:
                # Simple test to see if credentials are valid-ish
                # This is a placeholder, real test would involve IMAP login attempt
                test_result = "Configuration looks good (basic check passed)"
            except Exception as e:
                test_result = f"Test failed: {str(e)}"
        
        return jsonify({
            "success": True,
            "health": {
                "email_configured": email_configured,
                "password_configured": password_configured,
                "cache_status": cache_status,
                "test_result": test_result
            }
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route('/v1/api')
def scammer_keys_api_v1():
    """Process Classplus DRM URLs with automatic token management"""
    try:
        classplus_url = request.args.get('url')
        
        if not classplus_url:
            return jsonify({"success": False, "error": "Missing required parameter: url"}), 400
            
        if not (classplus_url.startswith("http://") or classplus_url.startswith("https://")):
            return jsonify({"success": False, "error": "Invalid URL format"}), 400
        
        # --- FIXED: Use internal function call instead of external HTTP request ---
        access_token = get_or_generate_token()
        if not access_token:
             return jsonify({
                 "success": False, 
                 "error": "Failed to obtain authentication token"
             }), 500
             
        result = process_classplus_drm_url(classplus_url, access_token)
        
        if result["success"]:
            return jsonify(result)
        else:
            return jsonify(result), 400
            
    except Exception as e:
        return jsonify({"success": False, "error": f"Internal Server Error: {str(e)}"}), 500

@app.route('/api/process-non-drm')
def process_non_drm_content():
    """Process non-DRM content with automatic token management"""
    try:
        non_drm_url = request.args.get('url')
        quality = request.args.get('quality', '720')
        use_token = request.args.get('use_token', 'true').lower() == 'true'
        
        if not non_drm_url:
            return jsonify({"success": False, "error": "Missing URL parameter"}), 400
            
        sanitized_title = re.sub(r'[^\w\-_\. ]', '_', non_drm_url.split('/')[-1].split('.')[0])[:50] or "NonDRM_Content"
        
        token = None
        if use_token and ('classplusapp.com' in non_drm_url or 'media-cdn.classplusapp.com' in non_drm_url):
            # --- FIXED: Use internal function call instead of external HTTP request ---
            token = get_or_generate_token() # This will get or generate and return the token string
        
        if token and ('classplusapp.com' in non_drm_url or 'media-cdn.classplusapp.com' in non_drm_url):
            headers = {'x-access-token': token}
            
            if 'videos.classplusapp.com' in non_drm_url:
                # --- FIXED: Removed extra space ---
                response = requests.get(
                    f'{API_BASE_URL}/cams/uploader/video/jw-signed-url?url={non_drm_url}', 
                    headers=headers, 
                    timeout=30
                )
                if response.status_code == 200:
                    data = response.json()
                    if 'url' in data:
                        non_drm_url = data['url']
        
        if non_drm_url.endswith('.m3u8') or 'playlist.m3u8' in non_drm_url or 'hls' in non_drm_url.lower():
            yt_dlp_cmd = (
                f'yt-dlp -o "{sanitized_title}.%(ext)s" '
                f'-f "bestvideo[height<={quality}]+bestaudio/best[height<={quality}]" '
                f'--external-downloader aria2c '
                f'--downloader-args "aria2c: -x 16 -j 32 -s 16 -k 1M --file-allocation=prealloc" '
                f'--hls-prefer-native '
                f'--no-check-certificate '
                f'--no-warnings '
                f'--concurrent-fragments 16 '
                f'--fragment-retries 10 '
                f'--retry-sleep fragment=5 '
                f'"{non_drm_url}"'
            )
        elif non_drm_url.endswith(('.mp4', '.mov', '.webm', '.avi', '.mkv')):
            yt_dlp_cmd = (
                f'yt-dlp -o "{sanitized_title}.%(ext)s" '
                f'--external-downloader aria2c '
                f'--downloader-args "aria2c: -x 16 -j 32 -s 8 -k 2M" '
                f'--no-warnings "{non_drm_url}"'
            )
        else:
            yt_dlp_cmd = f'yt-dlp -o "{sanitized_title}.%(ext)s" --no-warnings "{non_drm_url}"'
        
        return jsonify({
            "success": True,
            "download_instructions": {
                "type": "m3u8" if '.m3u8' in non_drm_url else "direct",
                "url": non_drm_url,
                "yt_dlp_cmd": yt_dlp_cmd,
                "token_used": token is not None,
                "token_source": "api" if token else "none"
            }
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/docs')
def docs():
    """API documentation"""
    return jsonify({
        "api_name": "Classplus Token & Download API",
        "version": "1.0",
        "owner": OWNER,
        "description": "API to generate Classplus tokens and process DRM/Non-DRM content",
        "endpoints": {
            "/": {"method": "GET", "description": "API information"},
            "/health": {"method": "GET", "description": "Health check"},
            "/api/generate-token": {
                "method": "POST",
                "description": "Generate a new Classplus token",
                "response": {
                    "success": "true",
                    "token": "generated_token",
                    "expires_in": "40 minutes"
                }
            },
            "/api/get-token": {
                "method": "GET",
                "description": "Get a valid token (cached or new)",
                "response": {
                    "success": "true",
                    "token": "valid_token",
                    "source": "cache or new"
                }
            },
            "/v1/api": {
                "method": "GET",
                "description": "Process Classplus DRM URLs",
                "parameters": {"url": "Classplus DRM URL"},
                "response": {
                    "success": "true",
                    "url": "signed_mpd_url"
                }
            },
            "/api/process-non-drm": {
                "method": "GET",
                "description": "Process non-DRM content",
                "parameters": {
                    "url": "Non-DRM URL",
                    "quality": "Video quality (default: 720)",
                    "use_token": "Use token for Classplus URLs (default: true)"
                },
                "response": {
                    "success": "true",
                    "download_instructions": {
                        "type": "m3u8 or direct",
                        "url": "processed_url",
                        "yt_dlp_cmd": "optimized_download_command"
                    }
                }
            }
        },
        "note": "Make sure EMAIL_ADDRESS and EMAIL_APP_PASSWORD are set in environment variables"
    })

# Vercel handler
# Standard for Flask, no special handler needed if `app` is correctly defined.
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host='0.0.0.0', port=port, debug=False) # Set debug=False for production
