"""
from os import getenv


API_ID = int(getenv("API_ID", " yha pr"))
API_HASH = getenv("API_HASH", "yha pr")
BOT_TOKEN = getenv("BOT_TOKEN", "yha pr")
OWNER_ID = int(getenv("OWNER_ID", "yha pr"))
SUDO_USERS = list(map(int, getenv("SUDO_USERS", "yha pr").split()))
MONGO_URL = getenv("MONGO_DB", "yha")

CHANNEL_ID = int(getenv("CHANNEL_ID", "-"))
PREMIUM_LOGS = int(getenv("PREMIUM_LOGS", "-"))
API_HASH = environ.get("API_HASH", "yha pr")

"""
#




# --------------M----------------------------------

import os
from os import getenv
# ---------------R---------------------------------
API_ID = int(os.environ.get("API_ID", "yha"))
# ------------------------------------------------
API_HASH = os.environ.get("API_HASH", "yha")
# ----------------D--------------------------------
BOT_TOKEN = os.environ.get("BOT_TOKEN", "yha")
# -----------------A-------------------------------
BOT_USERNAME = os.environ.get("yha without @")
# ------------------X------------------------------
OWNER_ID = int(os.environ.get("OWNER_ID", "yha"))
# ------------------X------------------------------

SUDO_USERS = list(map(int, getenv("SUDO_USERS", "yha").split()))
# ------------------------------------------------
CHANNEL_ID = int(os.environ.get("CHANNEL_ID", "-"))
# ------------------------------------------------
MONGO_URL = os.environ.get("MONGO_URL", "yha")
# -----------------------------------------------
PREMIUM_LOGS = int(os.environ.get("PREMIUM_LOGS", "-"))

