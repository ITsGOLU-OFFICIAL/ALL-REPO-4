import os
from os import getenv


# ------------------------------------------------
API_ID = int(os.environ.get("API_ID", "10170481"))
# ------------------------------------------------
API_HASH = os.environ.get("API_HASH","22dd74455eb31c9aca628c3008580142")
# ------------------------------------------------
BOT_TOKEN = os.environ.get("BOT_TOKEN", "7962090977:AAF4At3t7LTLIfQbGaD61TSlufF6tNxqtr8")
# ------------------------------------------------
BOT_USERNAME = os.environ.get("BOT_USERNAME", "@ITsGOLU_Extractor_Bot")
BOT_TEXT = ":𝐈𝐓'𝐬𝐆𝐎𝐋𝐔.™®:"
# ------------------------------------------------
OWNER_ID = int(os.environ.get("OWNER_ID", "8048202739"))
# ------------------------------------------------
# //LOG CHANNEL ID 
CHANNEL_ID = int(os.environ.get("CHANNEL_ID", "-1002731819287"))

# //FORCE_CHANNEL_ID
CHANNEL_ID2 = int(os.environ.get("CHANNEL_ID2", "-1002789797374")) 
# ------------------------------------------------
MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://vikassonawale0:JWyQFas7vlG1bkaL@cluster0.beermge.mongodb.net/?retryWrites=true&w=majority")
# -----------------------------------------------
PREMIUM_LOGS = int(os.environ.get("PREMIUM_LOGS", "-1002731819287"))
# -----------------------------------------------
join = '<a href="https://t.me/+l186M_g6vWRhMjFl">✳️ JOIN BACKUP</a>'
# -----------------------------------------------
UNSPLASH_ACCESS_KEY = 'RabDRmuXXBobanmwwbvpP5LwoG4J8ox34y5Sstz-9jk'
# -----------------------------------------------
UNSPLASH_QUERY = 'animal baby'
# -----------------------------------------------
ADMIN_BOT_USERNAME = "ITsGOLU_Extractor_Bot" #without @

THUMB_URL = os.environ.get("THUMB_URL", "https://i.ibb.co/DPCmWSKV/1000003297-3.png")




# # Bot configuration
# API_ID = int(os.environ.get("API_ID", "22746239"))
# API_HASH = os.environ.get("API_HASH", "a98ec8cfd8572a3a7c936cf828fe6215")
# BOT_TOKEN = os.environ.get("BOT_TOKEN", "7547829346:AAGyfvOu47EciNhC7NUGSDEDFuBaetYYusw")
# BOT_USERNAME = os.environ.get("BOT_USERNAME", "MassRPBot")
# OWNER_ID = int(os.environ.get("OWNER_ID", "7463601722"))
# SUDO_USERS = list(map(int, getenv("SUDO_USERS", "7463601722").split()))
# CHANNEL_ID = int(os.environ.get("CHANNEL_ID", "-1002601604234"))
# MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://wadiro6523:08AwfhhKRdQaS1i6@cluster0.krzxuop.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
# PREMIUM_LOGS = int(os.environ.get("PREMIUM_LOGS", "-1002601604234"))
# THUMB_URL = os.environ.get("THUMB_URL", "https://i.fbcd.co/products/original/ug-circle-logo-design-2-e84695ca2ab9a697d2b2d7c928b0bf5f12bf18e076da241815e0372c8d617915.jpg")

